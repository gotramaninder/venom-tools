#!/usr/bin/env bash
# Cursor AI agent adapter

# Check if Cursor agent/CLI is available
ai_can_start() {
  command -v agent >/dev/null 2>&1 \
    || command -v cursor-agent >/dev/null 2>&1 \
    || command -v cursor >/dev/null 2>&1
}

# Start Cursor agent in a directory
# Usage: ai_start path [args...]
ai_start() {
  local path="$1"
  shift
  local configured_args=("${GTR_AI_CMD_ARGS[@]}")

  if ! ai_can_start; then
    log_error "Cursor agent not found. Install from https://cursor.com/docs/cli/installation"
    log_info "Current releases use 'agent'; legacy 'cursor-agent' and 'cursor' commands are also supported"
    return 1
  fi

  if [ ! -d "$path" ]; then
    log_error "Directory not found: $path"
    return 1
  fi

  # Prefer the current standalone CLI, then fall back to legacy commands.
  if command -v agent >/dev/null 2>&1; then
    (cd "$path" && agent "${configured_args[@]}" "$@")
  elif command -v cursor-agent >/dev/null 2>&1; then
    (cd "$path" && cursor-agent "${configured_args[@]}" "$@")
  elif command -v cursor >/dev/null 2>&1; then
    # Try various Cursor CLI patterns (implementation varies by version)
    (cd "$path" && cursor cli "${configured_args[@]}" "$@") 2>/dev/null || (cd "$path" && cursor "${configured_args[@]}" "$@")
  fi
}
