#!/usr/bin/env bash
# Platform-specific utilities

# Detect operating system
# Returns: darwin, linux, or windows
detect_os() {
  case "$OSTYPE" in
    darwin*)
      echo "darwin"
      ;;
    linux*)
      echo "linux"
      ;;
    msys*|cygwin*|win32*)
      echo "windows"
      ;;
    *)
      # Fallback to uname
      case "$(uname -s 2>/dev/null)" in
        Darwin)
          echo "darwin"
          ;;
        Linux)
          echo "linux"
          ;;
        MINGW*|MSYS*|CYGWIN*)
          echo "windows"
          ;;
        *)
          echo "unknown"
          ;;
      esac
      ;;
  esac
}

# Open a directory in the system's GUI file browser
# Usage: open_in_gui path
open_in_gui() {
  local path="$1"
  local os

  os=$(detect_os)

  case "$os" in
    darwin)
      open "$path" 2>/dev/null || true
      ;;
    linux)
      # Try common Linux file managers
      if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$path" >/dev/null 2>&1 || true
      elif command -v gnome-open >/dev/null 2>&1; then
        gnome-open "$path" >/dev/null 2>&1 || true
      fi
      ;;
    windows)
      if command -v cygpath >/dev/null 2>&1; then
        cmd.exe /c start "" "$(cygpath -w "$path")" 2>/dev/null || true
      else
        cmd.exe /c start "" "$path" 2>/dev/null || true
      fi
      ;;
    *)
      log_warn "Cannot open GUI on unknown OS"
      return 1
      ;;
  esac
}

# Escape a string for safe interpolation into AppleScript double-quoted strings
# Handles backslashes and double quotes that would break AppleScript syntax
_escape_applescript() {
  local s="$1"
  s="${s//\\/\\\\}"
  s="${s//\"/\\\"}"
  printf '%s' "$s"
}

# Spawn a new terminal window/tab in a directory
# Usage: spawn_terminal_in path title [command]
# Note: Best-effort implementation, may not work on all systems
spawn_terminal_in() {
  local path="$1"
  local title="$2"
  local cmd="${3:-}"
  local os

  os=$(detect_os)

  case "$os" in
    darwin)
      # Escape variables for AppleScript string interpolation
      local shell_path safe_cd safe_title safe_cmd
      # Quote for the terminal shell first, then for the AppleScript string.
      # A variable preserves replacement backslashes consistently in Bash 3.2+.
      local escaped_quote="'\\''"
      shell_path="${path//\'/$escaped_quote}"
      safe_cd=$(_escape_applescript "cd -- '$shell_path'")
      safe_title=$(_escape_applescript "$title")
      safe_cmd=$(_escape_applescript "$cmd")

      # Pre-compute optional AppleScript write-text line (avoids set -e abort in heredoc)
      local iterm_cmd_line=""
      if [ -n "$safe_cmd" ]; then
        iterm_cmd_line="write text \"$safe_cmd\""
      fi

      # Try iTerm2 first, then Terminal.app
      if osascript -e 'tell application "System Events" to get name of first application process whose frontmost is true' 2>/dev/null | grep -q "iTerm"; then
        osascript <<-EOF 2>/dev/null || true
					tell application "iTerm"
						tell current window
							create tab with default profile
							tell current session
								write text "$safe_cd"
								set name to "$safe_title"
								$iterm_cmd_line
							end tell
						end tell
					end tell
				EOF
      else
        osascript <<-EOF 2>/dev/null || true
					tell application "Terminal"
						do script "$safe_cd; $safe_cmd"
						set custom title of front window to "$safe_title"
					end tell
				EOF
      fi
      ;;
    linux)
      local shell_after="${SHELL:-/bin/sh}"
      # shellcheck disable=SC2016 # The script is intentionally evaluated by sh in the new terminal.
      local terminal_script='cd "$1" || exit 1
shift
if [ "$#" -gt 0 ]; then
  "$@"
fi
exec "$SHELL_AFTER"'
      # Try common terminal emulators
      if command -v gnome-terminal >/dev/null 2>&1; then
        if [ -n "$cmd" ]; then
          gnome-terminal --working-directory="$path" --title="$title" -- env SHELL_AFTER="$shell_after" sh -c "$terminal_script" sh "$path" bash -lc "$cmd" 2>/dev/null || true
        else
          gnome-terminal --working-directory="$path" --title="$title" -- env SHELL_AFTER="$shell_after" sh -c "$terminal_script" sh "$path" 2>/dev/null || true
        fi
      elif command -v konsole >/dev/null 2>&1; then
        if [ -n "$cmd" ]; then
          konsole --workdir "$path" -p "tabtitle=$title" -e env SHELL_AFTER="$shell_after" sh -c "$terminal_script" sh "$path" bash -lc "$cmd" 2>/dev/null || true
        else
          konsole --workdir "$path" -p "tabtitle=$title" -e env SHELL_AFTER="$shell_after" sh -c "$terminal_script" sh "$path" 2>/dev/null || true
        fi
      elif command -v xterm >/dev/null 2>&1; then
        if [ -n "$cmd" ]; then
          xterm -T "$title" -e env SHELL_AFTER="$shell_after" sh -c "$terminal_script" sh "$path" bash -lc "$cmd" 2>/dev/null || true
        else
          xterm -T "$title" -e env SHELL_AFTER="$shell_after" sh -c "$terminal_script" sh "$path" 2>/dev/null || true
        fi
      else
        log_warn "No supported terminal emulator found"
        return 1
      fi
      ;;
    windows)
      # Try Windows Terminal, then fallback to cmd
      if command -v wt >/dev/null 2>&1; then
        if [ -n "$cmd" ]; then
          wt -d "$path" cmd.exe /k "$cmd" 2>/dev/null || true
        else
          wt -d "$path" 2>/dev/null || true
        fi
      else
        if [ -n "$cmd" ]; then
          cmd.exe /c start "$title" cmd.exe /k "cd /d \"$path\" && $cmd" 2>/dev/null || true
        else
          cmd.exe /c start "$title" cmd.exe /k "cd /d \"$path\"" 2>/dev/null || true
        fi
      fi
      ;;
    *)
      log_warn "Cannot spawn terminal on unknown OS"
      return 1
      ;;
  esac
}
