#!/usr/bin/env bash
# Adapter loading infrastructure — registries, builders, generic fallbacks, and loaders
# shellcheck disable=SC2329 # Functions defined inside adapter builders are invoked indirectly

# ── Editor Registry ────────────────────────────────────────────────────
# Declarative definitions for standard editor adapters.
# Custom adapters (nano) remain as override files in adapters/editor/.
#
# Format: name|cmd|type|err_msg|flags
#   name    — adapter name (used in --editor flag, config, completions)
#   cmd     — executable to check/invoke (must be in PATH)
#   type    — "standard" (GUI, opens directory) or "terminal" (runs in current tty)
#   err_msg — user-facing message when cmd is not found
#   flags   — comma-separated modifiers (optional):
#               "workspace" — pass .code-workspace file instead of directory
#               "background" — launch with & (for terminal editors that fork)
#               "dot" — cd to directory and pass "." instead of full path
#
# Loading: file override (adapters/editor/<name>.sh) → registry → generic PATH fallback
_EDITOR_REGISTRY="
antigravity|agy-ide|standard|Antigravity 'agy-ide' command not found. Install from https://antigravity.google|workspace,dot
atom|atom|standard|Atom (legacy) not found. Atom was sunset; see https://github.blog/news-insights/product-news/sunsetting-atom/|
cursor|cursor|standard|Cursor not found. Install from https://cursor.com or enable the shell command.|workspace
emacs|emacs|terminal|Emacs not found. Install from https://www.gnu.org/software/emacs/|background
idea|idea|standard|IntelliJ IDEA 'idea' command not found. Enable shell launcher in Tools > Create Command-line Launcher|
nvim|nvim|terminal|Neovim not found. Install from https://neovim.io|
pycharm|pycharm|standard|PyCharm 'pycharm' command not found. Enable shell launcher in Tools > Create Command-line Launcher|
sublime|subl|standard|Sublime Text 'subl' command not found. Install from https://www.sublimetext.com|
vim|vim|terminal|Vim not found. Install via your package manager.|
vscode|code|standard|VS Code 'code' command not found. Install from https://code.visualstudio.com|workspace
webstorm|webstorm|standard|WebStorm 'webstorm' command not found. Enable shell launcher in Tools > Create Command-line Launcher|
zed|zed|standard|Zed not found. Install from https://zed.dev|
"

# ── AI Tool Registry ──────────────────────────────────────────────────
# Declarative definitions for standard AI coding tool adapters.
# Custom adapters (claude, cursor) remain as override files in adapters/ai/.
#
# Format: name|cmd|err_msg|info_lines
#   name       — adapter name (used in --ai flag, config, completions)
#   cmd        — executable to check/invoke (must be in PATH)
#   err_msg    — user-facing message when cmd is not found
#   info_lines — semicolon-separated additional help lines shown on error
#
# Loading: file override (adapters/ai/<name>.sh) → registry → generic PATH fallback
_AI_REGISTRY="
antigravity|agy|Antigravity CLI not found. Install from https://antigravity.google|See https://antigravity.google/docs/cli/getting-started for more information
aider|aider|Aider not found. Install with: python -m pip install aider-install && aider-install|See https://aider.chat/docs/install.html for more information
auggie|auggie|Auggie CLI not found. Install with: npm install -g @augmentcode/auggie|See https://docs.augmentcode.com/cli/overview for more information
codex|codex|Codex CLI not found. Install with: npm install -g @openai/codex|Or: brew install codex;See https://github.com/openai/codex for more info
continue|cn|Continue CLI (legacy) not found.|Continue is no longer actively maintained; see https://github.com/continuedev/continue
copilot|copilot|GitHub Copilot CLI not found.|Install with: npm install -g @github/copilot;Or: brew install copilot-cli;See https://github.com/github/copilot-cli for more information
gemini|gemini|Gemini CLI not found. Install with: npm install -g @google/gemini-cli|Or: brew install gemini-cli;See https://github.com/google-gemini/gemini-cli for more info
opencode|opencode|OpenCode not found. Install from https://opencode.ai|Make sure the 'opencode' CLI is available in your PATH
"

# Registry lookup — find an adapter entry by name
# Usage: _registry_lookup <registry_content> <name>
# Prints matching line on success, returns 1 on miss
_registry_lookup() {
  local registry="$1" name="$2"
  local line
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    if [ "${line%%|*}" = "$name" ]; then
      printf "%s" "$line"
      return 0
    fi
  done <<EOF
$registry
EOF
  return 1
}

# Load an editor adapter from a registry entry
# Parses fields and calls the appropriate builder
_load_from_editor_registry() {
  local entry="$1"
  # Parse: name|cmd|type|err_msg|flags
  local remainder="$entry"
  local name="${remainder%%|*}"; remainder="${remainder#*|}"
  local cmd="${remainder%%|*}"; remainder="${remainder#*|}"
  local type="${remainder%%|*}"; remainder="${remainder#*|}"
  local err_msg="${remainder%%|*}"; remainder="${remainder#*|}"
  local flags="$remainder"

  _EDITOR_CMD="$cmd"
  _EDITOR_ERR_MSG="$err_msg"
  _EDITOR_WORKSPACE=0
  _EDITOR_BACKGROUND=0
  _EDITOR_DOT=0

  case ",$flags," in
    *,workspace,*) _EDITOR_WORKSPACE=1 ;;
  esac
  case ",$flags," in
    *,background,*) _EDITOR_BACKGROUND=1 ;;
  esac
  case ",$flags," in
    *,dot,*) _EDITOR_DOT=1 ;;
  esac

  case "$type" in
    terminal) _editor_define_terminal ;;
    *)        _editor_define_standard ;;
  esac
}

# Load an AI adapter from a registry entry
# Parses fields and calls the standard builder
_load_from_ai_registry() {
  local entry="$1"
  # Parse: name|cmd|err_msg|info_lines
  local remainder="$entry"
  local name="${remainder%%|*}"; remainder="${remainder#*|}"
  local cmd="${remainder%%|*}"; remainder="${remainder#*|}"
  local err_msg="${remainder%%|*}"; remainder="${remainder#*|}"
  local info_lines_raw="$remainder"

  _AI_CMD="$cmd"
  _AI_ERR_MSG="$err_msg"
  _AI_INFO_LINES=()

  if [ -n "$info_lines_raw" ]; then
    local old_ifs="$IFS"
    IFS=';'
    set -f  # Disable globbing during split
    # shellcheck disable=SC2086
    set -- $info_lines_raw
    set +f
    _AI_INFO_LINES=("$@")
    IFS="$old_ifs"
  fi

  _ai_define_standard
}

# List all adapter names from a registry
# Usage: _list_registry_names <registry_content>
_list_registry_names() {
  local registry="$1"
  local names="" line
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    names="${names:+$names, }${line%%|*}"
  done <<EOF
$registry
EOF
  printf "%s" "$names"
}

# Generic adapter functions (used when no explicit adapter file exists)
# These will be overridden if an adapter file is sourced
# Globals set by load_editor_adapter:
#   GTR_EDITOR_CMD, GTR_EDITOR_CMD_NAME, GTR_EDITOR_CMD_ARGS
editor_can_open() {
  command -v "$GTR_EDITOR_CMD_NAME" >/dev/null 2>&1
}

editor_open() {
  local path="$1"
  local workspace="${2:-}"
  local target="$path"

  # Use workspace file if provided and exists
  if [ -n "$workspace" ] && [ -f "$workspace" ]; then
    # shellcheck disable=SC2034
    target="$workspace"
  fi

  _run_configured_command "$GTR_EDITOR_CMD_NAME" "${GTR_EDITOR_CMD_ARGS[@]}" "$target"
}

# Globals set by load_ai_adapter:
#   GTR_AI_CMD, GTR_AI_CMD_NAME, GTR_AI_CMD_ARGS
ai_can_start() {
  command -v "$GTR_AI_CMD_NAME" >/dev/null 2>&1
}

ai_start() {
  local path="$1"
  shift
  (cd "$path" && _run_configured_command "$GTR_AI_CMD_NAME" "${GTR_AI_CMD_ARGS[@]}" "$@")
}

# Assign an array to a caller-provided variable name.
# Bash 3.2 has no namerefs, so this uses a safely quoted eval assignment.
_set_array_var() {
  local var_name="$1"
  shift

  case "$var_name" in
    [a-zA-Z_][a-zA-Z0-9_]*) ;;
    *) return 1 ;;
  esac

  local assignment="${var_name}=("
  local item
  for item in "$@"; do
    assignment="${assignment}$(printf '%q ' "$item")"
  done
  assignment="${assignment})"

  eval "$assignment"
}

# Split a config-supplied command string without shell evaluation.
# Usage: _parse_configured_command <out_array_name> <command_string>
_parse_configured_command() {
  local out_var="$1"
  local command_string="$2"
  local length="${#command_string}"
  local i=0 char="" token="" state="normal" escaped=0 token_started=0
  local parsed_tokens=()

  while [ "$i" -lt "$length" ]; do
    char="${command_string:$i:1}"

    case "$state" in
      normal)
        if [ "$escaped" -eq 1 ]; then
          token="${token}${char}"
          token_started=1
          escaped=0
        else
          case "$char" in
            "\\")
              escaped=1
              token_started=1
              ;;
            " " | $'\t' | $'\n')
              if [ "$token_started" -eq 1 ]; then
                parsed_tokens+=("$token")
                token=""
                token_started=0
              fi
              ;;
            "'")
              state="single"
              token_started=1
              ;;
            '"')
              state="double"
              token_started=1
              ;;
            *)
              token="${token}${char}"
              token_started=1
              ;;
          esac
        fi
        ;;
      single)
        if [ "$char" = "'" ]; then
          state="normal"
        else
          token="${token}${char}"
        fi
        ;;
      double)
        if [ "$escaped" -eq 1 ]; then
          token="${token}${char}"
          token_started=1
          escaped=0
        else
          case "$char" in
            "\\")
              escaped=1
              token_started=1
              ;;
            '"')
              state="normal"
              ;;
            *)
              token="${token}${char}"
              token_started=1
              ;;
          esac
        fi
        ;;
    esac

    i=$((i + 1))
  done

  [ "$escaped" -eq 0 ] || return 1
  [ "$state" = "normal" ] || return 1

  if [ "$token_started" -eq 1 ]; then
    parsed_tokens+=("$token")
  fi

  [ "${#parsed_tokens[@]}" -gt 0 ] || return 1
  _set_array_var "$out_var" "${parsed_tokens[@]}"
}

_configured_command_is_wrapper() {
  local cmd_name="$1"
  case "$cmd_name" in
    sh | bash | zsh | dash | ksh | fish | env | eval | source | . | python | python3 | node | ruby | perl | php | lua | pwsh | powershell)
      return 0
      ;;
  esac
  return 1
}

_configured_command_is_safe() {
  [ "$#" -gt 0 ] || return 1

  local cmd_name="$1"
  shift

  case "$cmd_name" in
    */* | *\\*)
      return 1
      ;;
  esac

  if _configured_command_is_wrapper "$cmd_name" && [ "$#" -gt 0 ]; then
    return 1
  fi

  return 0
}

# Run a config-supplied command argv that has already been parsed and validated.
# Usage: _run_configured_command <argv...>
_run_configured_command() {
  [ "$#" -gt 0 ] || return 1
  "$@"
}

# Standard AI adapter builder — used by adapter files that follow the common pattern
# Sets globals then call this: _AI_CMD, _AI_ERR_MSG, _AI_INFO_LINES (array)
_ai_define_standard() {
  # shellcheck disable=SC2317 # Functions are called indirectly via adapter dispatch
  ai_can_start() {
    command -v "$_AI_CMD" >/dev/null 2>&1
  }

  # shellcheck disable=SC2317
  ai_start() {
    local path="$1"; shift
    if ! ai_can_start; then
      log_error "$_AI_ERR_MSG"
      local _line
      for _line in "${_AI_INFO_LINES[@]}"; do
        log_info "$_line"
      done
      return 1
    fi
    if [ ! -d "$path" ]; then
      log_error "Directory not found: $path"
      return 1
    fi
    (cd "$path" && "$_AI_CMD" "$@")
  }
}

# Standard editor adapter builder — used by adapter files that follow the common pattern
# Sets globals then call this: _EDITOR_CMD, _EDITOR_ERR_MSG, _EDITOR_WORKSPACE (optional, 0 or 1), _EDITOR_DOT (optional, 0 or 1)
_editor_define_standard() {
  # shellcheck disable=SC2317 # Functions are called indirectly via adapter dispatch
  editor_can_open() {
    command -v "$_EDITOR_CMD" >/dev/null 2>&1
  }

  # shellcheck disable=SC2317
  editor_open() {
    local path="$1"
    local workspace="${2:-}"
    if ! editor_can_open; then
      log_error "$_EDITOR_ERR_MSG"
      return 1
    fi
    if [ "${_EDITOR_WORKSPACE:-0}" = "1" ] && [ -n "$workspace" ] && [ -f "$workspace" ]; then
      "$_EDITOR_CMD" "$workspace"
    elif [ "${_EDITOR_DOT:-0}" = "1" ]; then
      (cd "$path" && "$_EDITOR_CMD" .)
    else
      "$_EDITOR_CMD" "$path"
    fi
  }
}

# Terminal editor adapter builder — for editors that run in the current terminal
# Sets globals then call this: _EDITOR_CMD, _EDITOR_ERR_MSG, _EDITOR_BACKGROUND (optional, 0 or 1)
_editor_define_terminal() {
  # shellcheck disable=SC2317 # Functions are called indirectly via adapter dispatch
  editor_can_open() {
    command -v "$_EDITOR_CMD" >/dev/null 2>&1
  }

  # shellcheck disable=SC2317
  editor_open() {
    local path="$1"
    if ! editor_can_open; then
      log_error "$_EDITOR_ERR_MSG"
      return 1
    fi
    if [ "${_EDITOR_BACKGROUND:-0}" = "1" ]; then
      "$_EDITOR_CMD" "$path" &
    else
      (cd "$path" && "$_EDITOR_CMD" .)
    fi
  }
}

# Validate a relative workspace file against the physical worktree root.
# Follow internal symlinks without requiring readlink -f (unavailable on macOS).
# Return the original path so workspace-relative editor settings keep their meaning.
# Returns 1 for missing files, link cycles, absolute config paths or escapes.
_workspace_file_within_worktree() {
  local worktree_path="$1" relative_path="$2" root path parent target os
  local links=0
  os=$(detect_os)
  # Windows accepts backslashes as separators, including in traversal paths.
  if [ "$os" = windows ]; then relative_path="${relative_path//\\//}"; fi
  case "$relative_path" in
    /*|[a-zA-Z]:*|\\*) return 1 ;;
  esac
  # Sentinels preserve trailing newlines in physical directory/link names.
  root=$(canonicalize_path "$worktree_path" && printf '.') || return 1
  root="${root%$'\n.'}"
  path="${root%/}/$relative_path"

  while :; do
    parent=$(canonicalize_path "${path%/*}" && printf '.') || return 1
    parent="${parent%$'\n.'}"
    path="${parent%/}/${path##*/}"
    [ -L "$path" ] || break
    [ "$links" -lt 40 ] || return 1
    links=$((links + 1))
    target=$(readlink "$path" && printf '.') || return 1
    target="${target%$'\n.'}"
    if [ "$os" = windows ]; then target="${target//\\//}"; fi
    path="${parent%/}/$target"
    case "$target" in
      /*) path="$target" ;;
      [a-zA-Z]:/*) if [ "$os" = windows ]; then path="$target"; fi ;;
    esac
  done

  [ -f "$path" ] || return 1
  case "$path" in
    "${root%/}/"*) printf '%s\n' "$worktree_path/$relative_path" ;;
    *) return 1 ;;
  esac
}

# Resolve workspace file for VS Code/Cursor/Antigravity editors.
# Workspace data is not command-trust-gated; confine it for every config source.
# Returns the workspace file path if found, empty otherwise
resolve_workspace_file() {
  local worktree_path="$1"

  # Check config first (gtr.editor.workspace or editor.workspace in .gtrconfig)
  local configured
  configured=$(cfg_default gtr.editor.workspace "" "" editor.workspace)

  # Opt-out: "none" disables workspace lookup entirely
  if [ "$configured" = "none" ]; then
    return 0
  fi

  if [ -n "$configured" ]; then
    _workspace_file_within_worktree "$worktree_path" "$configured" || true
    # Explicit config set - don't fall through to auto-detect
    return 0
  fi

  # Auto-detect: find first .code-workspace in worktree root
  local ws_file
  ws_file=$(find "$worktree_path" -maxdepth 1 -name "*.code-workspace" -type f 2>/dev/null | head -1)
  if [ -n "$ws_file" ]; then
    _workspace_file_within_worktree "$worktree_path" "${ws_file##*/}" || true
  fi
}

# Load an adapter by type (shared implementation for editor and AI adapters)
# Usage: _load_adapter <type> <name> <label> <builtin_list> <path_hint>
_load_adapter() {
  local type="$1" name="$2" label="$3" builtin_list="$4" path_hint="$5"
  local parsed_args=()
  if ! _parse_configured_command parsed_args "$name" \
    || ! _configured_command_is_safe "${parsed_args[@]}"; then
    log_error "$label '$name' is not a safe executable command"
    log_info "Use a PATH command name, optionally with flags (e.g., 'code --wait')"
    return 1
  fi

  local adapter_selector="${parsed_args[0]}"
  local cmd_args=("${parsed_args[@]:1}")

  local adapter_file="$GTR_DIR/adapters/${type}/${adapter_selector}.sh"

  # 1. Try loading explicit adapter file (custom overrides like claude, nano)
  case "$adapter_selector" in
    */* | *..* | *\\*) ;;
    *)
      if [ -f "$adapter_file" ]; then
        if [ "$type" = "editor" ]; then
          # shellcheck disable=SC2034 # Used by sourced override adapters.
          GTR_EDITOR_CMD="$name"
          GTR_EDITOR_CMD_NAME="$adapter_selector"
          GTR_EDITOR_CMD_ARGS=("${cmd_args[@]}")
        else
          # shellcheck disable=SC2034 # Used by sourced override adapters.
          GTR_AI_CMD="$name"
          GTR_AI_CMD_NAME="$adapter_selector"
          GTR_AI_CMD_ARGS=("${cmd_args[@]}")
        fi
        # shellcheck disable=SC1090
        . "$adapter_file"
        return 0
      fi
      ;;
  esac

  # 2. Try registry lookup (declarative adapters)
  local registry entry
  if [ "$type" = "editor" ]; then
    registry="$_EDITOR_REGISTRY"
  else
    registry="$_AI_REGISTRY"
  fi

  if entry=$(_registry_lookup "$registry" "$name" || exit 1); then
    if [ "$type" = "editor" ]; then
      _load_from_editor_registry "$entry"
    else
      _load_from_ai_registry "$entry"
    fi
    return 0
  fi

  # 3. Generic fallback: command already validated and resolved in PATH
  local cmd_name="$adapter_selector"
  if ! type -P "$cmd_name" >/dev/null 2>&1; then
    log_error "$label '$name' not found"
    log_info "Built-in adapters: $builtin_list"
    log_info "Or use any $label command available in your PATH (e.g., $path_hint)"
    return 1
  fi

  # Set globals for generic adapter functions
  # Note: $name may contain arguments (e.g., "code --wait", "bunx @github/copilot@latest")
  if [ "$type" = "editor" ]; then
    # shellcheck disable=SC2034 # Exposed for adapter state/introspection.
    GTR_EDITOR_CMD="$name"
    GTR_EDITOR_CMD_NAME="$cmd_name"
    # shellcheck disable=SC2034 # Used by sourced override adapters.
    GTR_EDITOR_CMD_ARGS=("${cmd_args[@]}")
  else
    # shellcheck disable=SC2034 # Exposed for adapter state/introspection.
    GTR_AI_CMD="$name"
    GTR_AI_CMD_NAME="$cmd_name"
    # shellcheck disable=SC2034 # Used by sourced override adapters.
    GTR_AI_CMD_ARGS=("${cmd_args[@]}")
  fi
}

load_editor_adapter() {
  local builtin_names
  builtin_names="$(_list_registry_names "$_EDITOR_REGISTRY"), nano"
  _load_adapter "editor" "$1" "Editor" "$builtin_names" "code-insiders, hx"
}

load_ai_adapter() {
  local builtin_names
  builtin_names="$(_list_registry_names "$_AI_REGISTRY"), claude, cursor"
  _load_adapter "ai" "$1" "AI tool" "$builtin_names" "bunx, gpt"
}
