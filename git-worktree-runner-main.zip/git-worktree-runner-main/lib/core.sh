#!/usr/bin/env bash
# Core git worktree operations

# --- Context Globals Contract ---
# Resolver functions set these globals as a return mechanism (Bash lacks multi-return).
# Callers should copy into locals immediately after calling the resolver.
#
# resolve_repo_context() -> _ctx_repo_root  _ctx_base_dir  _ctx_prefix
# resolve_worktree()     -> _ctx_is_main    _ctx_worktree_path  _ctx_branch
declare _ctx_repo_root _ctx_base_dir _ctx_prefix
declare _ctx_is_main _ctx_worktree_path _ctx_branch

# Discover the root of the main git repository
# Works correctly from both the main repo and from inside worktrees.
# Returns: absolute path to main repo root
# Exit code: 0 on success, 1 if not in a git repo
discover_repo_root() {
  local root
  if ! root=$(_resolve_main_repo_root); then
    log_error "Not in a git repository"
    return 1
  fi

  printf "%s" "$root"
}

# Sanitize branch name for use as directory name
# Usage: sanitize_branch_name branch_name
# Converts special characters to hyphens for valid folder names
sanitize_branch_name() {
  local branch="$1"

  # Replace slashes, spaces, and other problematic chars with hyphens
  # Remove any leading/trailing hyphens
  printf "%s" "$branch" | sed -e 's/[\/\\ :*?"<>|#]/-/g' -e 's/^-*//' -e 's/-*$//'
}

# Prefixes name folders; worktrees.dir selects their parent directory.
# Reject both POSIX and Windows separators instead of changing configured names.
_validate_worktree_prefix() {
  case "$1" in
    */*|*\\*)
      log_error "Invalid gtr.worktrees.prefix: path separators are not allowed; use gtr.worktrees.dir for directories"
      return 1
      ;;
  esac
  return 0
}

# Canonicalize a path to its absolute form, resolving symlinks
# Usage: canonicalize_path path
# Returns: canonical path or empty string on failure
canonicalize_path() {
  local path="$1"
  # Unset CDPATH to prevent unexpected directory changes
  # Suppress stderr to hide errors for non-existent directories
  # Use subshell to avoid changing current working directory
  ( unset CDPATH && cd -P -- "$path" 2>/dev/null && pwd -P )
}

# Assign a canonical path without stripping trailing newline bytes. Remove only
# pwd's final delimiter and the sentinel, and propagate canonicalization errors.
# Usage: _canonicalize_path_into variable path
_canonicalize_path_into() {
  local _canonical_path
  _canonical_path=$(canonicalize_path "$2" && printf '.') || return $?
  printf -v "$1" '%s' "${_canonical_path%$'\n.'}"
}

# Resolve the base directory for worktrees
# Usage: resolve_base_dir repo_root
resolve_base_dir() {
  local repo_root="$1"
  local repo_name
  local base_dir

  repo_name=$(basename "$repo_root")

  # Check config first (gtr.worktrees.dir), then environment (GTR_WORKTREES_DIR), then default
  base_dir=$(cfg_default "gtr.worktrees.dir" "GTR_WORKTREES_DIR" "")

  if [ -z "$base_dir" ]; then
    # Default: <repo>-worktrees next to the repo
    base_dir="$(dirname "$repo_root")/${repo_name}-worktrees"
  else
    # Expand literal tilde to home directory
    # Patterns must quote ~ to prevent bash tilde expansion in case arms
    # shellcheck disable=SC2088
    case "$base_dir" in
      "~/"*) base_dir="$HOME/${base_dir#"~/"}" ;;
      "~") base_dir="$HOME" ;;
    esac

    # Check if absolute or relative
    if [ "${base_dir#/}" = "$base_dir" ]; then
      # Relative path - resolve from repo root
      base_dir="$repo_root/$base_dir"
    fi
    # Absolute paths (starting with /) are used as-is
  fi

  # Canonicalize base_dir if it exists
  if [ -d "$base_dir" ]; then
    local canonical_base
    _canonicalize_path_into canonical_base "$base_dir"
    if [ -n "$canonical_base" ]; then
      base_dir="$canonical_base"
    fi
    # If canonicalization fails (empty result), base_dir keeps its absolute form
  fi

  # Canonicalize repo_root before comparison
  local canonical_repo_root
  _canonicalize_path_into canonical_repo_root "$repo_root"
  # Warn if canonicalization fails (indicates repository issue)
  if [ -z "$canonical_repo_root" ]; then
    log_warn "Unable to canonicalize repository path: $repo_root"
    canonical_repo_root="$repo_root"
  fi

  # Warn if worktree dir is inside repo (but not a sibling)
  if [[ "$base_dir" == "$canonical_repo_root"/* ]]; then
    local rel_path="${base_dir#"$canonical_repo_root"/}"
    # Check if .gitignore exists and whether it includes the worktree directory
    if [ -f "$canonical_repo_root/.gitignore" ]; then
      if ! grep -qE "^/?${rel_path}/?\$|^/?${rel_path}/\*?\$" "$canonical_repo_root/.gitignore" 2>/dev/null; then
        log_warn "Worktrees are inside repository at: $rel_path"
        log_warn "Consider adding '/$rel_path/' to .gitignore to avoid committing worktrees"
      fi
    else
      log_warn "Worktrees are inside repository at: $rel_path"
      log_warn "Consider adding '/$rel_path/' to .gitignore"
    fi
  fi

  printf "%s" "$base_dir"
}

# Resolve the default remote name
# Usage: resolve_default_remote
resolve_default_remote() {
  cfg_default "gtr.defaultRemote" "GTR_DEFAULT_REMOTE" "origin"
}

# Resolve the default branch name
# Usage: resolve_default_branch [repo_root] [remote]
resolve_default_branch() {
  local repo_root="${1:-$(pwd)}"
  local remote="${2:-$(resolve_default_remote)}"
  local default_branch
  local configured_branch

  # Check config first
  configured_branch=$(cfg_default "gtr.defaultBranch" "GTR_DEFAULT_BRANCH" "auto")

  if [ "$configured_branch" != "auto" ]; then
    printf "%s" "$configured_branch"
    return 0
  fi

  # Auto-detect from the selected remote's HEAD
  default_branch=$(git symbolic-ref --quiet "refs/remotes/$remote/HEAD" 2>/dev/null || true)
  default_branch="${default_branch#refs/remotes/"$remote"/}"

  if [ -n "$default_branch" ]; then
    printf "%s" "$default_branch"
    return 0
  fi

  # Fallback: try common branch names
  if git show-ref --verify --quiet "refs/remotes/$remote/main"; then
    printf "main"
  elif git show-ref --verify --quiet "refs/remotes/$remote/master"; then
    printf "master"
  else
    # Last resort: just use 'main'
    printf "main"
  fi
}

# Get current branch name with Git 2.22+ fallback
# Usage: get_current_branch [directory]
# Returns: branch name, "HEAD" if detached, or empty
get_current_branch() {
  if [ -n "${1:-}" ]; then
    git -C "$1" branch --show-current 2>/dev/null ||
      git -C "$1" rev-parse --abbrev-ref HEAD 2>/dev/null
  else
    git branch --show-current 2>/dev/null ||
      git rev-parse --abbrev-ref HEAD 2>/dev/null
  fi
}

# Get the current branch of a worktree (with detached HEAD normalization)
# Usage: current_branch worktree_path
current_branch() {
  local worktree_path="$1"

  if [ ! -d "$worktree_path" ]; then
    return 1
  fi

  local branch
  branch=$(get_current_branch "$worktree_path")

  # Normalize detached HEAD or empty (failed detection)
  if [ -z "$branch" ] || [ "$branch" = "HEAD" ]; then
    branch="(detached)"
  fi

  printf "%s" "$branch"
}

_worktree_record_status() {
  local detached="$1" locked="$2" prunable="$3"

  if [ "$locked" -eq 1 ]; then
    printf "locked"
  elif [ "$prunable" -eq 1 ]; then
    printf "prunable"
  elif [ "$detached" -eq 1 ]; then
    printf "detached"
  else
    printf "ok"
  fi
}

_emit_worktree_record() {
  local repo_root="$1"
  local wt_path="$2"
  local wt_branch="$3"
  local wt_detached="$4"
  local wt_locked="$5"
  local wt_prunable="$6"

  [ -z "$wt_path" ] && return 0

  local is_main=0 branch="$wt_branch" status wt_path_canonical
  _canonicalize_path_into wt_path_canonical "$wt_path" || wt_path_canonical="$wt_path"
  if [ "$wt_path" = "$repo_root" ] || [ "$wt_path_canonical" = "$repo_root" ]; then
    is_main=1
  fi
  [ -z "$branch" ] && branch="(detached)"
  status=$(_worktree_record_status "$wt_detached" "$wt_locked" "$wt_prunable")

  printf "is_main %s\n" "$is_main"
  printf "path %s\n" "$(_tsv_escape_field "$wt_path")"
  printf "branch %s\n" "$(_tsv_escape_field "$branch")"
  printf "status %s\n\n" "$status"
}

_parse_worktree_records() {
  local repo_root_canonical="$1"
  local delimiter="$2"
  local wt_path="" wt_branch="" wt_detached=0 wt_locked=0 wt_prunable=0
  local field

  while IFS= read -r -d "$delimiter" field; do
    case "$field" in
      "")
        _emit_worktree_record "$repo_root_canonical" "$wt_path" "$wt_branch" "$wt_detached" "$wt_locked" "$wt_prunable"
        wt_path=""
        wt_branch=""
        wt_detached=0
        wt_locked=0
        wt_prunable=0
        ;;
      "worktree "*)
        if [ -n "$wt_path" ]; then
          _emit_worktree_record "$repo_root_canonical" "$wt_path" "$wt_branch" "$wt_detached" "$wt_locked" "$wt_prunable"
          wt_branch=""
          wt_detached=0
          wt_locked=0
          wt_prunable=0
        fi
        wt_path="${field#worktree }"
        ;;
      "branch refs/heads/"*)
        wt_branch="${field#branch refs/heads/}"
        ;;
      "branch "*)
        wt_branch="${field#branch }"
        ;;
      detached)
        wt_detached=1
        ;;
      locked*)
        wt_locked=1
        ;;
      prunable*)
        wt_prunable=1
        ;;
    esac
  done

  _emit_worktree_record "$repo_root_canonical" "$wt_path" "$wt_branch" "$wt_detached" "$wt_locked" "$wt_prunable"
}

# List registered git worktrees for a repository.
# Usage: list_worktree_records repo_root
# Output: blank-line-delimited records with is_main/path/branch/status fields
list_worktree_records() {
  local repo_root="$1"
  local repo_root_canonical
  _canonicalize_path_into repo_root_canonical "$repo_root" || repo_root_canonical="$repo_root"

  if git -C "$repo_root" worktree list --porcelain -z >/dev/null 2>&1; then
    _parse_worktree_records "$repo_root_canonical" "" < <(git -C "$repo_root" worktree list --porcelain -z 2>/dev/null)
  else
    # Old porcelain writes raw newlines in paths, which can impersonate another
    # row. Reject that ambiguous format before emitting any selectable records.
    local common_dir gitdir_file registered_gitdir
    case "$repo_root" in
      *$'\n'*)
        log_error "Newline-containing worktree paths require Git with NUL worktree listing support"
        return 1
        ;;
    esac
    common_dir=$(git -C "$repo_root" rev-parse --git-common-dir) || return 1
    case "$common_dir" in
      /* | [a-zA-Z]:/*) ;;
      *) common_dir="$repo_root/$common_dir" ;;
    esac
    for gitdir_file in "$common_dir"/worktrees/*/gitdir; do
      [ -f "$gitdir_file" ] || continue
      registered_gitdir=$(cat "$gitdir_file") || return 1
      case "$registered_gitdir" in
        *$'\n'*)
          log_error "Newline-containing worktree paths require Git with NUL worktree listing support"
          return 1
          ;;
      esac
    done
    _parse_worktree_records "$repo_root_canonical" $'\n' < <(git -C "$repo_root" worktree list --porcelain 2>/dev/null)
  fi
}

# Get the status of a worktree from git
# Usage: worktree_status worktree_path
# Returns: status (ok, detached, locked, prunable, or missing)
worktree_status() {
  local target_path="$1"
  local target_path_canonical
  _canonicalize_path_into target_path_canonical "$target_path" || target_path_canonical="$target_path"

  local status="ok"
  local found=0
  local repo_root
  repo_root=$(_resolve_main_repo_root) || return 1

  local is_main="" path="" branch="" record_status="" line path_canonical
  while IFS= read -r line; do
    case "$line" in
      "")
        [ -z "$path" ] && continue
        _canonicalize_path_into path_canonical "$path" || path_canonical="$path"
        if [ "$path" = "$target_path" ] || [ "$path_canonical" = "$target_path_canonical" ]; then
          found=1
          status="$record_status"
          break
        fi
        is_main=""
        path=""
        branch=""
        record_status=""
        ;;
      "is_main "*)
        is_main="${line#is_main }"
        ;;
      "path "*)
        path=$(_tsv_unescape_field "${line#path }" && printf '.') || return 1
        path="${path%.}"
        ;;
      "branch "*)
        branch=$(_tsv_unescape_field "${line#branch }")
        ;;
      "status "*)
        record_status="${line#status }"
        ;;
    esac
  done <<EOF
$(list_worktree_records "$repo_root")
EOF

  if [ "$found" -eq 0 ] && [ -n "$path" ]; then
    _canonicalize_path_into path_canonical "$path" || path_canonical="$path"
    if [ "$path" = "$target_path" ] || [ "$path_canonical" = "$target_path_canonical" ]; then
      found=1
      status="$record_status"
    fi
  fi

  # If worktree not found in git's list
  if [ "$found" -eq 0 ]; then
    status="missing"
  fi

  printf "%s" "$status"
}

_tsv_escape_field() {
  local value="$1"
  value=${value//\\/\\\\}
  value=${value//$'\t'/$'\\t'}
  value=${value//$'\n'/$'\\n'}
  printf "%s" "$value"
}

_tsv_unescape_field() {
  local value="$1" out="" char next

  while [ -n "$value" ]; do
    char="${value:0:1}"
    value="${value:1}"

    if [ "$char" = "\\" ]; then
      if [ -z "$value" ]; then
        out="${out}\\"
        break
      fi

      next="${value:0:1}"
      value="${value:1}"
      case "$next" in
        t)
          out="${out}"$'\t'
          ;;
        n)
          out="${out}"$'\n'
          ;;
        "\\")
          out="${out}\\"
          ;;
        *)
          out="${out}\\${next}"
          ;;
      esac
    else
      out="${out}${char}"
    fi
  done

  printf "%s" "$out"
}

_print_resolved_target() {
  local is_main="$1" path="$2" branch="$3"
  printf "%s\t%s\t%s\n" "$is_main" "$(_tsv_escape_field "$path")" "$(_tsv_escape_field "$branch")"
}

# Resolve an escaped absolute path identity against this repository's registry.
# Compare encoded fields before decoding so tabs/newlines cannot split records.
_resolve_path_target() {
  local identifier="$1" repo_root="$2"
  local is_main="" path="" branch="" line decoded_path
  while IFS= read -r line; do
    case "$line" in
      "")
        if [ -n "$path" ] && [ "path:$path" = "$identifier" ]; then
          decoded_path=$(_tsv_unescape_field "$path" && printf '.') || return 1
          decoded_path="${decoded_path%.}"
          [ -d "$decoded_path" ] || break
          printf '%s\t%s\t%s\n' "$is_main" "$path" "$branch"
          return 0
        fi
        is_main="" path="" branch=""
        ;;
      "is_main "*) is_main="${line#is_main }" ;;
      "path "*) path="${line#path }" ;;
      "branch "*) branch="${line#branch }" ;;
    esac
  done <<EOF
$(list_worktree_records "$repo_root")

EOF
  log_error "Registered worktree not found for identity: $identifier"
  return 1
}

# Resolve a registered path identity, branch, literal folder alias, or main ID '1'.
# Usage: resolve_target identifier repo_root base_dir prefix
# Returns: tab-separated "is_main\tpath\tbranch" with escaped fields on success (is_main: 1 for main repo, 0 for worktrees)
# Exit code: 0 on success, 1 if not found
resolve_target() {
  local identifier="$1"
  local repo_root="$2"
  local base_dir="$3"
  local prefix="$4"
  local branch sanitized_name preferred_path alias_path=""

  case "$identifier" in
    "" | . | ..)
      log_error "Worktree not found for branch: $identifier"
      return 1
      ;;
  esac

  _validate_worktree_prefix "$prefix" || return 1

  # ':' cannot occur in a branch; the absolute path also avoids folder aliases.
  # Never fall back to branch resolution for a stale or invalid path identity.
  case "$identifier" in
    path:/* | path:[a-zA-Z]:/*)
      _resolve_path_target "$identifier" "$repo_root"
      return $?
      ;;
  esac

  # Special case: ID 1 is always the repo root
  if [ "$identifier" = "1" ]; then
    branch=$(get_current_branch "$repo_root") || return 1
    _print_resolved_target "1" "$repo_root" "$branch"
    return 0
  fi

  # A sanitized name is only a preference among exact branch matches, never
  # evidence of branch identity or worktree membership.
  _canonicalize_path_into base_dir "$base_dir" || true
  sanitized_name=$(sanitize_branch_name "$identifier")
  preferred_path="$base_dir/${prefix}${sanitized_name}"

  # Preserve --folder/--name and sanitized folder aliases, but only when the
  # user supplied the literal folder name. In particular, feat/login must not
  # fall back to the folder for the different branch feat-login.
  case "$identifier" in
    */* | *\\*) ;;
    *) alias_path="$base_dir/${prefix}${identifier}" ;;
  esac

  # Git's registry is authoritative, including external and nested worktrees.
  # Save an alias match until every record has been checked for an exact branch.
  local branch_target="" alias_target=""
  local is_main="" wt_path="" wt_branch="" line
  while IFS= read -r line; do
    case "$line" in
      "")
        if [ -n "$wt_path" ] && [ -d "$wt_path" ]; then
          if [ "$wt_branch" = "$identifier" ]; then
            if [ "$is_main" = "1" ]; then
              _print_resolved_target "$is_main" "$wt_path" "$wt_branch"
              return 0
            fi
            if [ -z "$branch_target" ] || [ "$wt_path" = "$preferred_path" ]; then
              branch_target=$(_print_resolved_target "$is_main" "$wt_path" "$wt_branch")
            fi
          fi
          if [ "$wt_path" = "$alias_path" ]; then
            alias_target=$(_print_resolved_target "$is_main" "$wt_path" "$wt_branch")
          fi
        fi
        is_main=""
        wt_path=""
        wt_branch=""
        ;;
      "is_main "*)
        is_main="${line#is_main }"
        ;;
      "path "*)
        wt_path=$(_tsv_unescape_field "${line#path }" && printf '.') || return 1
        wt_path="${wt_path%.}"
        ;;
      "branch "*)
        wt_branch=$(_tsv_unescape_field "${line#branch }")
        ;;
    esac
  done <<EOF
$(list_worktree_records "$repo_root")

EOF

  if [ -n "$branch_target" ]; then
    printf "%s\n" "$branch_target"
    return 0
  fi
  if [ -n "$alias_target" ]; then
    printf "%s\n" "$alias_target"
    return 0
  fi

  log_error "Worktree not found for branch: $identifier"
  return 1
}

# Unpack TSV output from resolve_target into globals.
# Sets: _ctx_is_main, _ctx_worktree_path, _ctx_branch
# Usage: unpack_target "$target_string"
unpack_target() {
  local escaped_path escaped_branch
  local IFS=$'\t'
  read -r _ctx_is_main escaped_path escaped_branch <<< "$1"
  # Preserve trailing newlines in a registered path through command substitution.
  _ctx_worktree_path=$(_tsv_unescape_field "$escaped_path" && printf '.') || return 1
  _ctx_worktree_path="${_ctx_worktree_path%.}"
  _ctx_branch=$(_tsv_unescape_field "$escaped_branch")
}

# Resolve an identifier to a worktree and set _ctx_* variables in one step
# Usage: resolve_worktree <identifier> <repo_root> <base_dir> <prefix>
# Sets: _ctx_is_main, _ctx_worktree_path, _ctx_branch
resolve_worktree() {
  local target
  # Guard the subshell too: a handled miss must not fire Bash 3.2's ERR trap.
  target=$(resolve_target "$1" "$2" "$3" "$4" || exit 1) || return 1
  unpack_target "$target"
}

# Try to create a worktree, handling the common log/add/report pattern.
# Usage: _try_worktree_add <path> <step_msg> <ok_msg> <add_source> [git_worktree_add_args...]
# Prints worktree path on success; returns 1 on failure (caller handles error).
# Note: step_msg may be empty to skip the log_step call.
_try_worktree_add() {
  local wt_path="$1" step_msg="$2" ok_msg="$3" add_source="$4"
  shift 4

  [ -n "$step_msg" ] && log_step "$step_msg"

  if [ -n "$add_source" ]; then
    git -C "$add_source" worktree add "$wt_path" "$@" >&2 || return 1
  else
    git worktree add "$wt_path" "$@" >&2 || return 1
  fi
  log_info "$ok_msg"
  printf "%s" "$wt_path"
  return 0
}

# Build and validate folder name from branch/custom/override.
# Prints sanitized folder name on success; returns 1 on validation failure.
# Usage: _resolve_folder_name <branch_name> [custom_name] [folder_override]
_resolve_folder_name() {
  local branch_name="$1" custom_name="${2:-}" folder_override="${3:-}"
  local sanitized_name

  if [ -n "$folder_override" ]; then
    sanitized_name=$(sanitize_branch_name "$folder_override")
  elif [ -n "$custom_name" ]; then
    local sanitized_custom
    sanitized_custom=$(sanitize_branch_name "$custom_name")
    if [ -z "$sanitized_custom" ] || [ "$sanitized_custom" = "." ] || [ "$sanitized_custom" = ".." ]; then
      log_error "Invalid --name value: $custom_name"
      return 1
    fi
    sanitized_name="$(sanitize_branch_name "$branch_name")-${sanitized_custom}"
  else
    sanitized_name=$(sanitize_branch_name "$branch_name")
  fi

  if [ -z "$sanitized_name" ] || [ "$sanitized_name" = "." ] || [ "$sanitized_name" = ".." ]; then
    if [ -n "$folder_override" ]; then
      log_error "Invalid --folder value: $folder_override"
    else
      log_error "Invalid worktree folder name derived from branch: $branch_name"
    fi
    return 1
  fi

  printf "%s" "$sanitized_name"
}

# Check if a branch exists on remote and/or locally.
# Sets globals: _wt_remote_exists, _wt_local_exists (0 or 1)
# Usage: _check_branch_refs <branch_name> [remote]
declare _wt_remote_exists _wt_local_exists
_check_branch_refs() {
  local branch_name="$1" remote="${2:-$(resolve_default_remote)}"

  _wt_remote_exists=0
  _wt_local_exists=0
  git show-ref --verify --quiet "refs/remotes/$remote/$branch_name" && _wt_remote_exists=1
  git show-ref --verify --quiet "refs/heads/$branch_name" && _wt_local_exists=1
  return 0
}

# Auto-track: create local tracking branch from remote if needed, then add worktree.
# Usage: _worktree_add_tracked <worktree_path> <branch_name> <remote> <add_source> [force_args...]
# shellcheck disable=SC2317  # Called indirectly from create_worktree
_worktree_add_tracked() {
  local wt_path="$1" branch_name="$2" remote="${3:-$(resolve_default_remote)}" add_source="${4:-}"
  shift 4

  log_step "Branch '$branch_name' exists on $remote"
  if git branch --track "$branch_name" "$remote/$branch_name" >/dev/null 2>&1; then
    log_info "Created local branch tracking $remote/$branch_name"
  fi
  _try_worktree_add "$wt_path" "" \
    "Worktree created tracking $remote/$branch_name" \
    "$add_source" \
    "$@" "$branch_name"
}

# Normalize a remote-tracking ref only when its prefix names a configured remote.
# Usage: _remote_branch_for_ref <ref> [repo_root]
# Prints: local branch portion for a configured remote ref, empty otherwise.
_remote_branch_for_ref() {
  local ref="$1" repo_root="${2:-}" remote default_remote matched_remote=""
  [ -n "$repo_root" ] || repo_root=$(_resolve_main_repo_root) || return 0
  case "$ref" in
    refs/remotes/*) ref="${ref#refs/remotes/}" ;;
    remotes/*) ref="${ref#remotes/}" ;;
  esac

  # The configured/default remote remains meaningful before the first fetch,
  # when it may not yet appear in `git remote` (common in isolated tests too).
  default_remote=$(resolve_default_remote)
  case "$ref" in
    "$default_remote/"*) matched_remote="$default_remote" ;;
  esac

  while IFS= read -r remote; do
    case "$ref" in
      "$remote/"*)
        if [ -z "$matched_remote" ] || [ "${#remote}" -gt "${#matched_remote}" ]; then
          matched_remote="$remote"
        fi
        ;;
    esac
  done < <(git -C "$repo_root" remote 2>/dev/null || true)
  [ -n "$matched_remote" ] && printf "%s" "${ref#"$matched_remote/"}"
  return 0
}

# Find the worktree that has a given local or remote-tracking ref checked out.
# Exact local branch names always win; remote prefixes are stripped only when
# they match a configured remote.
# Usage: _worktree_path_for_ref <ref>
# Prints: worktree path on match, empty otherwise.
_worktree_path_for_ref() {
  local ref="$1" repo_root current_path records resolved_ref branch_candidate
  [ -n "$ref" ] || return 0
  repo_root=$(_resolve_main_repo_root) || return 0
  current_path=$(git rev-parse --show-toplevel 2>/dev/null && printf '.') || current_path=""
  current_path="${current_path%$'\n.'}"
  if [ -n "$current_path" ]; then
    _canonicalize_path_into current_path "$current_path" || true
  fi

  # Let Git apply its own revision precedence and namespace shorthand rules.
  # Tags and other non-branch refs deliberately have no owning worktree.
  resolved_ref=$(git -C "$repo_root" rev-parse --verify --symbolic-full-name "$ref" 2>/dev/null || true)
  case "$resolved_ref" in
    refs/heads/*)
      branch_candidate="${resolved_ref#refs/heads/}"
      ;;
    refs/remotes/*)
      branch_candidate=$(_remote_branch_for_ref "$resolved_ref" "$repo_root")
      ;;
    refs/*)
      return 0
      ;;
    "")
      # A commit-ish that resolves without a symbolic ref (for example a tag
      # collision, SHA, or revision expression) has no unique owning worktree.
      if git -C "$repo_root" rev-parse --verify "${ref}^{commit}" >/dev/null 2>&1; then
        return 0
      fi
      # Preserve configured-remote matching before the first fetch, when the
      # remote-tracking ref does not exist yet.
      branch_candidate=$(_remote_branch_for_ref "$ref" "$repo_root")
      ;;
  esac
  [ -n "$branch_candidate" ] || return 0
  records=$(list_worktree_records "$repo_root")

  local path="" branch="" line
  local matched_path="" matched_current="" matched_count=0
  while IFS= read -r line; do
    case "$line" in
      "")
        if [ -n "$path" ] && [ "$branch" = "$branch_candidate" ]; then
          matched_count=$((matched_count + 1))
          [ -z "$matched_path" ] && matched_path="$path"
          [ -n "$current_path" ] && [ "$path" = "$current_path" ] && matched_current="$path"
        fi
        path=""
        branch=""
        ;;
      "path "*)
        path=$(_tsv_unescape_field "${line#path }" && printf '.') || return 1
        path="${path%.}"
        ;;
      "branch "*) branch=$(_tsv_unescape_field "${line#branch }") ;;
    esac
  done <<EOF
$records

EOF

  if [ -n "$matched_current" ]; then
    printf "%s" "$matched_current"
  elif [ "$matched_count" -eq 1 ]; then
    printf "%s" "$matched_path"
  elif [ "$matched_count" -gt 1 ]; then
    log_warn "Multiple worktrees use branch '$branch_candidate'; sparse-checkout source is ambiguous"
    return 2
  fi
  return 0
}

# Test whether sparse-checkout is configured, even if its pattern file is bad.
# Usage: _worktree_sparse_enabled <worktree_path>
_worktree_sparse_enabled() {
  local wt="$1"
  [ -n "$wt" ] || return 1
  local enabled
  enabled=$(git -C "$wt" config --bool core.sparseCheckout 2>/dev/null || true)
  [ "$enabled" = "true" ]
}

# Test whether a worktree has usable sparse-checkout settings.
# Usage: _worktree_is_sparse <worktree_path>
_worktree_is_sparse() {
  local wt="$1"
  _worktree_sparse_enabled "$wt" || return 1

  (
    cd "$wt" || exit 1
    local pattern_file
    pattern_file=$(git rev-parse --git-path info/sparse-checkout 2>/dev/null) || exit 1
    [ -r "$pattern_file" ] || exit 1
    git sparse-checkout list >/dev/null 2>&1
  )
}

# Resolve which worktree's sparse-checkout config a new worktree should inherit.
# Prefers the worktree holding from_ref, falling back to the current worktree.
# Only prints a path if the chosen worktree actually has sparse-checkout enabled;
# a matching but non-sparse worktree does not short-circuit the fallback.
# Usage: _resolve_sparse_source <from_ref>
# Prints: source worktree path if sparse-enabled, empty otherwise.
_resolve_sparse_source() {
  local from_ref="$1"
  local src status current

  # Prefer the worktree holding from_ref, but only if it is sparse-enabled.
  if src=$(_worktree_path_for_ref "$from_ref" && printf '.'); then
    src="${src%.}"
  else
    status=$?
    [ "$status" -eq 2 ] && return 0
  fi
  if [ -n "$src" ] && _worktree_is_sparse "$src"; then
    printf "%s" "$src"
    return 0
  fi
  if [ -n "$src" ] && _worktree_sparse_enabled "$src"; then
    log_warn "Sparse-checkout settings in $src are incomplete; falling back to a full checkout"
    return 0
  fi

  # Otherwise fall back to the current/top-level worktree if it is sparse.
  current=$(git rev-parse --show-toplevel 2>/dev/null && printf '.') || current=""
  current="${current%$'\n.'}"
  if [ -n "$current" ] && _worktree_is_sparse "$current"; then
    printf "%s" "$current"
    return 0
  fi
  if [ -n "$current" ] && [ "$current" != "$src" ] && _worktree_sparse_enabled "$current"; then
    log_warn "Sparse-checkout settings in $current are incomplete; falling back to a full checkout"
  fi

  return 0
}

# Compare the running Git's major/minor version.
# Usage: _git_version_at_least <major> <minor>
_git_version_at_least() {
  local required_major="$1" required_minor="$2"
  local version major minor
  version=$(git --version 2>/dev/null) || return 1
  version="${version#git version }"
  version="${version%% *}"
  major="${version%%.*}"
  minor="${version#*.}"
  minor="${minor%%.*}"
  [ -n "$major" ] || return 1
  case "$major$minor" in
    *[!0-9]* | "") return 1 ;;
  esac
  [ "$major" -gt "$required_major" ] && return 0
  [ "$major" -eq "$required_major" ] && [ "$minor" -ge "$required_minor" ] && return 0
  return 1
}

# Git 2.36+ natively copies sparse patterns and worktree config on worktree add.
_git_supports_sparse_inheritance() {
  _git_version_at_least 2 36
}

# Ensure a worktree is fully populated. When populate is 1, checkout is forced
# because the worktree may have been created with --no-checkout.
# Usage: _ensure_full_checkout <worktree> [populate]
_ensure_full_checkout() {
  local wt="$1" populate="${2:-0}"

  if _worktree_sparse_enabled "$wt"; then
    if ! git -C "$wt" sparse-checkout disable >/dev/null 2>&1; then
      log_warn "Could not disable sparse-checkout in $wt"
      return 1
    fi
    populate=1
  fi

  if [ "$populate" -eq 1 ] && ! git -C "$wt" checkout >/dev/null 2>&1; then
    log_warn "Could not populate full checkout in $wt"
    return 1
  fi
  return 0
}

# Create a new git worktree
# Usage: create_worktree base_dir prefix branch_name from_ref track_mode [skip_fetch] [force] [custom_name] [folder_override] [remote] [no_checkout] [add_source]
# track_mode: auto, remote, local, or none
# skip_fetch: 0 (default, fetch) or 1 (skip)
# force: 0 (default, check branch) or 1 (allow same branch in multiple worktrees)
# custom_name: optional custom name suffix (e.g., "backend" creates "feature-auth-backend")
# folder_override: optional complete folder name override (replaces default naming)
# no_checkout: 0 (default) or 1 (pass --no-checkout, e.g. for deferred sparse-checkout)
# add_source: worktree path whose context should be used only for `git worktree add`
create_worktree() {
  local base_dir="$1" prefix="$2" branch_name="$3" from_ref="$4"
  local track_mode="${5:-auto}" skip_fetch="${6:-0}" force="${7:-0}"
  local custom_name="${8:-}" folder_override="${9:-}"
  local remote="${10:-$(resolve_default_remote)}"
  local no_checkout="${11:-0}"
  local add_source="${12:-}"

  _validate_worktree_prefix "$prefix" || return 1

  local sanitized_name
  sanitized_name=$(_resolve_folder_name "$branch_name" "$custom_name" "$folder_override") || return 1

  local worktree_path="$base_dir/${prefix}${sanitized_name}"
  local force_args=()
  [ "$force" -eq 1 ] && force_args=(--force)
  [ "$no_checkout" -eq 1 ] && force_args+=(--no-checkout)

  if [ -d "$worktree_path" ]; then
    log_error "Worktree $sanitized_name already exists at $worktree_path"
    return 1
  fi

  mkdir -p "$base_dir"

  if [ "$skip_fetch" -eq 0 ]; then
    log_step "Fetching remote branches..."
    # Shared config can supply the remote; keep it out of option parsing.
    git fetch -- "$remote" 2>/dev/null || log_warn "Could not fetch from $remote"
  fi

  _check_branch_refs "$branch_name" "$remote"

  # Resolve from_ref to a commit SHA to prevent git's guess-remote logic
  # from overriding the -b flag when from_ref matches a remote branch name.
  # Try the ref as-is first, then with the selected remote prefix for remote-only refs.
  local resolved_ref
  resolved_ref=$(git rev-parse --verify "${from_ref}^{commit}" 2>/dev/null) \
    || resolved_ref=$(git rev-parse --verify "$remote/${from_ref}^{commit}" 2>/dev/null) \
    || resolved_ref="$from_ref"

  case "$track_mode" in
    remote)
      if [ "$_wt_remote_exists" -eq 1 ]; then
        _try_worktree_add "$worktree_path" \
          "Creating worktree from remote branch $remote/$branch_name" \
          "Worktree created tracking $remote/$branch_name" \
          "$add_source" \
          "${force_args[@]}" -b "$branch_name" "$remote/$branch_name" && return 0
        _try_worktree_add "$worktree_path" "" \
          "Worktree created tracking $remote/$branch_name" \
          "$add_source" \
          "${force_args[@]}" "$branch_name" && return 0
      fi
      log_error "Remote branch $remote/$branch_name does not exist"
      return 1
      ;;

    local)
      if [ "$_wt_local_exists" -eq 1 ]; then
        _try_worktree_add "$worktree_path" \
          "Creating worktree from local branch $branch_name" \
          "Worktree created with local branch $branch_name" \
          "$add_source" \
          "${force_args[@]}" "$branch_name" && return 0
      fi
      log_error "Local branch $branch_name does not exist"
      return 1
      ;;

    none)
      _try_worktree_add "$worktree_path" \
        "Creating new branch $branch_name from $from_ref" \
        "Worktree created with new branch $branch_name" \
        "$add_source" \
        "${force_args[@]}" -b "$branch_name" "$resolved_ref" && return 0
      log_error "Failed to create worktree with new branch"
      return 1
      ;;

    auto|*)
      if [ "$_wt_remote_exists" -eq 1 ] && [ "$_wt_local_exists" -eq 0 ]; then
        _worktree_add_tracked "$worktree_path" "$branch_name" "$remote" "$add_source" "${force_args[@]}" && return 0
      elif [ "$_wt_local_exists" -eq 1 ]; then
        _try_worktree_add "$worktree_path" \
          "Using existing local branch $branch_name" \
          "Worktree created with local branch $branch_name" \
          "$add_source" \
          "${force_args[@]}" "$branch_name" && return 0
      else
        _try_worktree_add "$worktree_path" \
          "Creating new branch $branch_name from $from_ref" \
          "Worktree created with new branch $branch_name" \
          "$add_source" \
          "${force_args[@]}" -b "$branch_name" "$resolved_ref" && return 0
      fi
      ;;
  esac

  log_error "Failed to create worktree"
  return 1
}

# Remove a git worktree
# Usage: remove_worktree worktree_path
remove_worktree() {
  local worktree_path="$1"
  local force="${2:-0}"

  if [ ! -d "$worktree_path" ]; then
    log_error "Worktree not found at $worktree_path"
    return 1
  fi

  local force_args=()
  if [ "$force" -eq 1 ]; then
    force_args=(--force)
  fi

  local remove_output
  if remove_output=$(git worktree remove "${force_args[@]}" "$worktree_path" 2>&1); then
    log_info "Worktree removed: $worktree_path"
    return 0
  else
    if [ -n "$remove_output" ]; then
      log_error "Failed to remove worktree: $remove_output"
    else
      log_error "Failed to remove worktree"
    fi
    return 1
  fi
}

# Resolve common repo context used by most cmd_* handlers.
# Sets globals: _ctx_repo_root, _ctx_base_dir, _ctx_prefix
# Usage: resolve_repo_context || exit 1
resolve_repo_context() {
  _ctx_repo_root=$(discover_repo_root) || return 1
  _ctx_base_dir=$(resolve_base_dir "$_ctx_repo_root")
  _ctx_prefix=$(cfg_default gtr.worktrees.prefix GTR_WORKTREES_PREFIX "")
  _validate_worktree_prefix "$_ctx_prefix" || return 1
}

# List all worktree branch names (excluding main repo)
# Usage: list_worktree_branches base_dir prefix [repo_root]
# Returns: newline-separated list of branch names
list_worktree_branches() {
  local base_dir="$1"
  local prefix="$2"
  local repo_root="${3:-}"
  if [ -z "$repo_root" ]; then
    repo_root=$(_resolve_main_repo_root) || return 0
  fi

  # base_dir and prefix are kept for the public helper contract. Worktree
  # discovery itself comes from Git's registry so nested registered worktrees
  # are included and arbitrary parent directories are ignored.
  : "$base_dir" "$prefix"

  local records
  records=$(list_worktree_records "$repo_root")

  local is_main="" path="" branch="" line
  while IFS= read -r line; do
    case "$line" in
      "")
        if [ "$is_main" != "1" ] && [ -n "$branch" ] && [ "$branch" != "(detached)" ]; then
          printf "%s\n" "$branch"
        fi
        is_main=""
        path=""
        branch=""
        ;;
      "is_main "*)
        is_main="${line#is_main }"
        ;;
      "path "*)
        path=$(_tsv_unescape_field "${line#path }" && printf '.') || return 1
        path="${path%.}"
        ;;
      "branch "*)
        branch=$(_tsv_unescape_field "${line#branch }")
        ;;
    esac
  done <<EOF
$records
EOF

  if [ "$is_main" != "1" ] && [ -n "$branch" ] && [ "$branch" != "(detached)" ]; then
    printf "%s\n" "$branch"
  fi
}
