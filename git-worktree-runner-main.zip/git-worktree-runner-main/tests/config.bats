#!/usr/bin/env bats
# Tests for lib/config.sh — key mapping, cfg_list helpers, formatting
load test_helper

setup() {
  source "$PROJECT_ROOT/lib/config.sh"
}

teardown() {
  if [ -n "${TEST_REPO:-}" ]; then
    teardown_integration_repo
    unset TEST_REPO TEST_WORKTREES_DIR
  fi
}

# ── Key mapping ──────────────────────────────────────────────────────────────

@test "cfg_map_to_file_key maps gtr.copy.include to copy.include" {
  result=$(cfg_map_to_file_key "gtr.copy.include")
  [ "$result" = "copy.include" ]
}

@test "cfg_map_to_file_key maps gtr.editor.default to defaults.editor" {
  result=$(cfg_map_to_file_key "gtr.editor.default")
  [ "$result" = "defaults.editor" ]
}

@test "cfg_map_to_file_key returns empty for unknown key" {
  result=$(cfg_map_to_file_key "gtr.nonexistent")
  [ -z "$result" ]
}

@test "cfg_map_from_file_key maps copy.include to gtr.copy.include" {
  result=$(cfg_map_from_file_key "copy.include")
  [ "$result" = "gtr.copy.include" ]
}

@test "cfg_map_from_file_key maps defaults.editor to gtr.editor.default" {
  result=$(cfg_map_from_file_key "defaults.editor")
  [ "$result" = "gtr.editor.default" ]
}

@test "cfg_map_from_file_key passes through gtr.* keys" {
  result=$(cfg_map_from_file_key "gtr.copy.include")
  [ "$result" = "gtr.copy.include" ]
}

@test "cfg_map_from_file_key returns empty for unknown non-gtr key" {
  result=$(cfg_map_from_file_key "totally.unknown")
  [ -z "$result" ]
}

@test "round-trip: all _CFG_KEY_MAP entries are bidirectional" {
  for pair in "${_CFG_KEY_MAP[@]}"; do
    local gtr_key="${pair%%|*}"
    local file_key="${pair#*|}"

    local mapped_file
    mapped_file=$(cfg_map_to_file_key "$gtr_key")
    [ "$mapped_file" = "$file_key" ]

    local mapped_gtr
    mapped_gtr=$(cfg_map_from_file_key "$file_key")
    [ "$mapped_gtr" = "$gtr_key" ]
  done
}

# ── Known key detection ──────────────────────────────────────────────────────

@test "_cfg_is_known_key returns 0 for gtr.copy.include" {
  _cfg_is_known_key "gtr.copy.include"
}

@test "_cfg_is_known_key returns 0 for gtr.hook.postCd" {
  _cfg_is_known_key "gtr.hook.postCd"
}

@test "_cfg_is_known_key returns 1 for unknown key" {
  ! _cfg_is_known_key "gtr.nonexistent"
}

# ── Boolean values ───────────────────────────────────────────────────────────

@test "cfg_bool uses Git boolean parsing for nonzero integers" {
  setup_integration_repo
  git -C "$TEST_REPO" config gtr.sparse.inherit 2

  cfg_bool gtr.sparse.inherit false
}

@test "cfg_bool skips an unsupported worktree config scope" {
  _cfg_read_bool() {
    [ "${2:-}" = "--worktree" ] && return 3
    [ "${2:-}" = "--local" ] && { printf "true"; return 0; }
    return 1
  }

  cfg_bool gtr.sparse.inherit false
}

# ── cfg_list deduplication ───────────────────────────────────────────────────

@test "_cfg_list_add_entry adds entry to result" {
  _cfg_list_seen=""
  _cfg_list_result=""
  _cfg_list_add_entry "local" "gtr.editor.default" "vscode"
  [[ "$_cfg_list_result" == *"gtr.editor.default"* ]]
  [[ "$_cfg_list_result" == *"vscode"* ]]
  [[ "$_cfg_list_result" == *"local"* ]]
}

@test "_cfg_list_add_entry deduplicates same key+value" {
  _cfg_list_seen=""
  _cfg_list_result=""
  _cfg_list_add_entry "local" "gtr.editor.default" "vscode"
  _cfg_list_add_entry "global" "gtr.editor.default" "vscode"
  # Should only appear once (local takes priority)
  local count
  count=$(printf '%s' "$_cfg_list_result" | grep -c "gtr.editor.default" || true)
  [ "$count" -eq 1 ]
}

@test "_cfg_list_add_entry allows same key with different values" {
  _cfg_list_seen=""
  _cfg_list_result=""
  _cfg_list_add_entry "local" "gtr.copy.include" ".env*"
  _cfg_list_add_entry "local" "gtr.copy.include" "*.config.js"
  local count
  count=$(printf '%s' "$_cfg_list_result" | grep -c "gtr.copy.include" || true)
  [ "$count" -eq 2 ]
}

# ── cfg_list formatting ─────────────────────────────────────────────────────

@test "_cfg_list_format shows message for empty output" {
  result=$(_cfg_list_format "")
  [ "$result" = "No gtr configuration found" ]
}

@test "_cfg_list_format formats scoped output (space-delimited)" {
  result=$(_cfg_list_format "gtr.editor.default vscode")
  [[ "$result" == *"gtr.editor.default"* ]]
  [[ "$result" == *"= vscode"* ]]
}

@test "_cfg_list_format formats auto output (unit-separator-delimited)" {
  local us=$'\x1f'
  local input="gtr.editor.default${us}vscode${us}local"
  result=$(_cfg_list_format "$input")
  [[ "$result" == *"gtr.editor.default"* ]]
  [[ "$result" == *"vscode"* ]]
  [[ "$result" == *"[local]"* ]]
}

# ── Repo context integration ─────────────────────────────────────────────────

@test "_resolve_main_repo_root returns the repo root from a subdirectory" {
  setup_integration_repo
  mkdir -p "$TEST_REPO/subdir/nested"
  cd "$TEST_REPO/subdir/nested"
  local expected
  expected=$(cd "$TEST_REPO" && pwd -P)

  result=$(_resolve_main_repo_root)
  [ "$result" = "$expected" ]
}

@test "_gtrconfig_path points at the repo root from a subdirectory" {
  setup_integration_repo
  mkdir -p "$TEST_REPO/subdir/nested"
  cd "$TEST_REPO/subdir/nested"
  local expected
  expected="$(cd "$TEST_REPO" && pwd -P)/.gtrconfig"

  result=$(_gtrconfig_path)
  [ "$result" = "$expected" ]
}
