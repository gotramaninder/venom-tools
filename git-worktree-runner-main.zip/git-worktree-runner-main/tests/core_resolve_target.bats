#!/usr/bin/env bats
# Tests for resolve_target, unpack_target, resolve_worktree in lib/core.sh

load test_helper

setup() {
  setup_integration_repo
  source_gtr_libs
}

teardown() {
  teardown_integration_repo
}

@test "resolve_target ID 1 returns main repo with is_main=1" {
  local result
  result=$(resolve_target "1" "$TEST_REPO" "$TEST_WORKTREES_DIR" "")
  [[ "$result" == "1"$'\t'"$TEST_REPO"* ]]
}

@test "resolve_target finds worktree by branch name" {
  create_test_worktree "find-me"
  local result
  result=$(resolve_target "find-me" "$TEST_REPO" "$TEST_WORKTREES_DIR" "")
  [[ "$result" == "0"$'\t'"$TEST_WORKTREES_DIR/find-me"$'\t'"find-me" ]]
}

@test "resolve_target resolves slashed branch to sanitized path" {
  create_test_worktree "feature/login"
  local result
  result=$(resolve_target "feature/login" "$TEST_REPO" "$TEST_WORKTREES_DIR" "")
  [[ "$result" == "0"$'\t'"$TEST_WORKTREES_DIR/feature-login"* ]]
}

@test "resolve_target returns 1 for unknown branch" {
  run resolve_target "nonexistent" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$status" -eq 1 ]
}

@test "resolve_target matches current branch in main repo as is_main=1" {
  local current
  current=$(git rev-parse --abbrev-ref HEAD)
  local result
  result=$(resolve_target "$current" "$TEST_REPO" "$TEST_WORKTREES_DIR" "")
  [[ "$result" == "1"$'\t'"$TEST_REPO"* ]]
}

@test "resolve_target handles prefix in path" {
  create_worktree "$TEST_WORKTREES_DIR" "wt-" "prefixed" "HEAD" "none" "1" >/dev/null
  local result
  result=$(resolve_target "prefixed" "$TEST_REPO" "$TEST_WORKTREES_DIR" "wt-")
  [[ "$result" == "0"$'\t'"$TEST_WORKTREES_DIR/wt-prefixed"* ]]
}

@test "resolve_target rejects traversal prefixes even when the destination exists" {
  local base_dir="$TEST_REPO/prefix-fixture/trees"
  mkdir -p "$base_dir" "$TEST_REPO/prefix-fixture/planted-feature"

  run resolve_target "feature" "$TEST_REPO" "$base_dir" "../planted-"

  [ "$status" -eq 1 ]
  [[ "$output" == *"Invalid gtr.worktrees.prefix"* ]]
}

@test "resolve_target rejects a sanitized collision with a different branch" {
  create_test_worktree "feat-login"

  run resolve_target "feat/login" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$status" -eq 1 ]
}

@test "resolve_target prefers the exact registered branch over a colliding folder" {
  create_test_worktree "feat-login"
  git worktree add "$TEST_WORKTREES_DIR/login-custom" -b feat/login

  resolve_worktree "feat/login" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$TEST_WORKTREES_DIR/login-custom" ]
  [ "$_ctx_branch" = "feat/login" ]
}

@test "resolve_target prefers an external exact branch over a literal folder alias" {
  git worktree add "$TEST_WORKTREES_DIR/alias" -b other-branch
  git worktree add "${TEST_REPO}-external" -b alias

  resolve_worktree "alias" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "${TEST_REPO}-external" ]
  [ "$_ctx_branch" = "alias" ]
}

@test "resolve_target keeps registered sanitized folder aliases" {
  create_test_worktree "feature/login"

  resolve_worktree "feature-login" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$TEST_WORKTREES_DIR/feature-login" ]
  [ "$_ctx_branch" = "feature/login" ]
}

@test "resolve_target keeps prefixed custom folders and named duplicate worktrees" {
  create_worktree "$TEST_WORKTREES_DIR" "wt-" "feature/login" "HEAD" "none" "1" "0" >/dev/null
  git worktree add --force "$TEST_WORKTREES_DIR/wt-feature-login-backend" feature/login
  git worktree add "$TEST_WORKTREES_DIR/wt-custom folder" -b another-branch

  resolve_worktree "feature/login" "$TEST_REPO" "$TEST_WORKTREES_DIR" "wt-"
  [ "$_ctx_worktree_path" = "$TEST_WORKTREES_DIR/wt-feature-login" ]
  resolve_worktree "feature-login-backend" "$TEST_REPO" "$TEST_WORKTREES_DIR" "wt-"
  [ "$_ctx_worktree_path" = "$TEST_WORKTREES_DIR/wt-feature-login-backend" ]
  [ "$_ctx_branch" = "feature/login" ]
  resolve_worktree "another-branch" "$TEST_REPO" "$TEST_WORKTREES_DIR" "wt-"
  [ "$_ctx_worktree_path" = "$TEST_WORKTREES_DIR/wt-custom folder" ]
}

@test "resolve_target keeps detached registered folder aliases" {
  git worktree add --detach "$TEST_WORKTREES_DIR/review" HEAD

  resolve_worktree "review" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$TEST_WORKTREES_DIR/review" ]
  [ "$_ctx_branch" = "(detached)" ]
}

@test "resolve_target rejects stray directories and dot targets" {
  local base="$TEST_REPO/worktrees"
  mkdir -p "$base/stray"
  local identifier
  for identifier in stray . .. ""; do
    run resolve_target "$identifier" "$TEST_REPO" "$base" ""
    [ "$status" -eq 1 ]
  done
}

@test "resolve_target ignores unrelated repositories in its base directory" {
  local foreign="$TEST_WORKTREES_DIR/impostor"
  mkdir -p "$foreign"
  git -C "$foreign" init --quiet
  git -C "$foreign" -c user.name=Test -c user.email=test@example.com commit --allow-empty -m init --quiet
  git -C "$foreign" branch -m foreign-branch

  run resolve_target "impostor" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$status" -eq 1 ]
  run resolve_target "foreign-branch" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$status" -eq 1 ]
}

@test "resolve_target does not accept symlink aliases to unregistered directories" {
  mkdir -p "$TEST_WORKTREES_DIR" "$TEST_REPO/stray"
  ln -s "$TEST_REPO/stray" "$TEST_WORKTREES_DIR/link"

  run resolve_target "link" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$status" -eq 1 ]
}

@test "resolve_target handles a symlinked base directory" {
  create_test_worktree "feature/login"
  ln -s "$TEST_WORKTREES_DIR" "$TEST_REPO/base-link"

  resolve_worktree "feature-login" "$TEST_REPO" "$TEST_REPO/base-link" ""
  [ "$_ctx_worktree_path" = "$TEST_WORKTREES_DIR/feature-login" ]
}

@test "resolve_target ID 1 takes precedence over a registered branch named 1" {
  git worktree add "$TEST_WORKTREES_DIR/numeric" -b 1

  resolve_worktree "1" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_is_main" = "1" ]
  [ "$_ctx_worktree_path" = "$TEST_REPO" ]
}

@test "resolve_target main branch takes precedence over a duplicate worktree" {
  local main_branch
  main_branch=$(git rev-parse --abbrev-ref HEAD)
  git worktree add --force "$TEST_WORKTREES_DIR/$main_branch" "$main_branch"

  resolve_worktree "$main_branch" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_is_main" = "1" ]
  [ "$_ctx_worktree_path" = "$TEST_REPO" ]
}

@test "resolve_target uses the porcelain fallback when Git lacks NUL records" {
  create_test_worktree "feature/login"
  git() {
    case "$*" in
      *"worktree list --porcelain -z") return 1 ;;
    esac
    command git "$@"
  }

  resolve_worktree "feature/login" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$TEST_WORKTREES_DIR/feature-login" ]
  [ "$_ctx_branch" = "feature/login" ]
  resolve_worktree "feature-login" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_branch" = "feature/login" ]
}

@test "unpack_target parses TSV into context globals" {
  local tsv="0"$'\t'"/some/path"$'\t'"my-branch"
  unpack_target "$tsv"
  [ "$_ctx_is_main" = "0" ]
  [ "$_ctx_worktree_path" = "/some/path" ]
  [ "$_ctx_branch" = "my-branch" ]
}

@test "unpack_target parses main repo TSV" {
  local tsv="1"$'\t'"/repo/root"$'\t'"main"
  unpack_target "$tsv"
  [ "$_ctx_is_main" = "1" ]
  [ "$_ctx_worktree_path" = "/repo/root" ]
  [ "$_ctx_branch" = "main" ]
}

@test "resolved target escaping round-trips tabs newlines and backslashes" {
  local value="/tmp/path"$'\t'"with"$'\n'"chars\\tail"
  local escaped
  escaped=$(_tsv_escape_field "$value")

  [ "$(_tsv_unescape_field "$escaped")" = "$value" ]
}

@test "resolve_worktree sets context globals" {
  create_test_worktree "ctx-test"
  resolve_worktree "ctx-test" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_is_main" = "0" ]
  [ "$_ctx_worktree_path" = "$TEST_WORKTREES_DIR/ctx-test" ]
  [ "$_ctx_branch" = "ctx-test" ]
}

@test "resolve_worktree preserves tab in externally registered worktree path" {
  local tab_path="${TEST_REPO}-external"$'\t'"tab"
  git -C "$TEST_REPO" worktree add "$tab_path" -b resolve-tab-path
  local expected_path
  expected_path=$(cd "$tab_path" && pwd -P)

  resolve_worktree "resolve-tab-path" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""

  [ "$_ctx_is_main" = "0" ]
  [ "$_ctx_worktree_path" = "$expected_path" ]
  [ "$_ctx_branch" = "resolve-tab-path" ]
}

@test "resolve_worktree returns 1 for unknown branch" {
  run resolve_worktree "nope" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$status" -eq 1 ]
}

@test "resolve_worktree preserves trailing newlines and rejects shortened siblings" {
  git worktree list --porcelain -z >/dev/null 2>&1 || skip "NUL worktree listing is unavailable"
  local suffix path branch escaped
  for suffix in $'\n' $'\n\n'; do
    branch="newline-${#suffix}"
    path="$TEST_WORKTREES_DIR/$branch$suffix"
    git worktree add -b "$branch" "$path" HEAD >/dev/null
    mkdir "$TEST_WORKTREES_DIR/$branch"
    escaped=$(_tsv_escape_field "$path")

    resolve_worktree "$branch" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
    [ "$_ctx_worktree_path" = "$path" ]
    [ "$_ctx_is_main" = 0 ]
    resolve_worktree "path:$escaped" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
    [ "$_ctx_worktree_path" = "$path" ]

    run resolve_worktree "path:$TEST_WORKTREES_DIR/$branch" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
    [ "$status" -eq 1 ]

    # A stale registry entry must not resolve to the still-existing sibling.
    rm -rf "$path"
    run resolve_worktree "$branch" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
    [ "$status" -eq 1 ]
    run resolve_worktree "path:$escaped" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
    [ "$status" -eq 1 ]
  done
}

@test "resolve_target preserves trailing newlines in a canonical base directory" {
  git worktree list --porcelain -z >/dev/null 2>&1 || skip "NUL worktree listing is unavailable"
  local base="$TEST_WORKTREES_DIR/base"$'\n\n'
  mkdir -p "$base" "$TEST_WORKTREES_DIR/base"
  git worktree add -b shared "$TEST_WORKTREES_DIR/a-first" HEAD >/dev/null
  git worktree add --force "$base/shared" shared >/dev/null
  git worktree add -b other "$base/alias" HEAD >/dev/null

  resolve_worktree shared "$TEST_REPO" "$base" ""
  [ "$_ctx_worktree_path" = "$base/shared" ]
  resolve_worktree alias "$TEST_REPO" "$base" ""
  [ "$_ctx_worktree_path" = "$base/alias" ]
}

@test "worktree_status distinguishes trailing newlines through canonicalization and fallback" {
  git worktree list --porcelain -z >/dev/null 2>&1 || skip "NUL worktree listing is unavailable"
  local suffix path branch link
  for suffix in $'\n' $'\n\n'; do
    branch="status-${#suffix}"
    path="$TEST_WORKTREES_DIR/$branch$suffix"
    link="$TEST_WORKTREES_DIR/link-${#suffix}"
    git worktree add -b "$branch" "$path" HEAD >/dev/null
    git worktree lock "$path"
    mkdir "$TEST_WORKTREES_DIR/$branch"
    ln -s "$path" "$link"

    [ "$(worktree_status "$path")" = locked ]
    [ "$(worktree_status "$link")" = locked ]
    [ "$(worktree_status "$TEST_WORKTREES_DIR/$branch")" = missing ]

    # Missing paths take the canonicalization fallback, still byte-for-byte.
    rm -rf "$path"
    [ "$(worktree_status "$path")" = locked ]
    [ "$(worktree_status "$TEST_WORKTREES_DIR/$branch")" = missing ]
  done
}

@test "list_worktree_records distinguishes main root from a trailing newlines sibling" {
  git worktree list --porcelain -z >/dev/null 2>&1 || skip "NUL worktree listing is unavailable"
  local main="$TEST_WORKTREES_DIR/main" path records escaped
  git clone --quiet "$TEST_REPO" "$main"
  path="$main"$'\n\n'
  git -C "$main" worktree add -b sibling "$path" HEAD >/dev/null
  escaped=$(_tsv_escape_field "$path")

  records=$(list_worktree_records "$main")
  [[ "$records" == *"is_main 0"$'\n'"path $escaped"$'\n'"branch sibling"* ]]
  # Canonicalizing an actual main root must preserve its trailing bytes too.
  local newline_root="$TEST_WORKTREES_DIR/root"$'\n\n'
  git clone --quiet "$TEST_REPO" "$newline_root"
  mkdir "$TEST_WORKTREES_DIR/root"
  escaped=$(_tsv_escape_field "$newline_root")
  records=$(list_worktree_records "$newline_root")
  [[ "$records" == *"is_main 1"$'\n'"path $escaped"$'\n'* ]]
}

@test "canonical path capture preserves trailing newlines and failure status" {
  local path="$TEST_WORKTREES_DIR/canonical"$'\n\n' result="unchanged"
  mkdir -p "$path"
  _canonicalize_path_into result "$path"
  [ "$result" = "$path" ]

  run _canonicalize_path_into result "$TEST_WORKTREES_DIR/missing"
  [ "$status" -ne 0 ]
}

# ── porcelain fallback ─────────────────────────────────────────────────────────

@test "resolve_target finds externally-created worktree via porcelain fallback" {
  # Create a worktree with raw git (outside gtr-managed directory)
  local ext_dir="${TEST_REPO}-external"
  git -C "$TEST_REPO" worktree add "$ext_dir" -b external-branch
  local result
  result=$(resolve_target "external-branch" "$TEST_REPO" "$TEST_WORKTREES_DIR" "")
  # Assert: found with is_main=0, correct branch, path ends with expected suffix
  [[ "$result" == "0"$'\t'*"-external"$'\t'"external-branch" ]]
}

@test "resolve_target finds nested externally-created worktree under base dir" {
  mkdir -p "$TEST_WORKTREES_DIR/jsmith"
  git -C "$TEST_REPO" worktree add "$TEST_WORKTREES_DIR/jsmith/my-feature" -b jsmith/my-feature

  local result
  result=$(resolve_target "jsmith/my-feature" "$TEST_REPO" "$TEST_WORKTREES_DIR" "")
  local expected_path
  expected_path=$(cd "$TEST_WORKTREES_DIR/jsmith/my-feature" && pwd -P)

  [[ "$result" == "0"$'\t'"$expected_path"$'\t'"jsmith/my-feature" ]]
}

@test "list_worktree_records reports normal detached and locked worktrees" {
  create_test_worktree "records-normal"
  git -C "$TEST_REPO" worktree add --detach "$TEST_WORKTREES_DIR/records-detached" HEAD
  create_test_worktree "records-locked"
  git -C "$TEST_REPO" worktree lock "$TEST_WORKTREES_DIR/records-locked" --reason "test lock"

  local records
  records=$(list_worktree_records "$TEST_REPO")
  local repo_root
  repo_root=$(cd "$TEST_REPO" && pwd -P)
  local normal_path detached_path locked_path
  normal_path=$(cd "$TEST_WORKTREES_DIR/records-normal" && pwd -P)
  detached_path=$(cd "$TEST_WORKTREES_DIR/records-detached" && pwd -P)
  locked_path=$(cd "$TEST_WORKTREES_DIR/records-locked" && pwd -P)

  [[ "$records" == *"is_main 1"$'\n'"path $repo_root"$'\n'*"status ok"* ]]
  [[ "$records" == *"is_main 0"$'\n'"path $normal_path"$'\n'"branch records-normal"$'\n'"status ok"* ]]
  [[ "$records" == *"is_main 0"$'\n'"path $detached_path"$'\n'"branch (detached)"$'\n'"status detached"* ]]
  [[ "$records" == *"is_main 0"$'\n'"path $locked_path"$'\n'"branch records-locked"$'\n'"status locked"* ]]

  git -C "$TEST_REPO" worktree unlock "$TEST_WORKTREES_DIR/records-locked"
}

@test "worktree_status handles registered path containing tab" {
  local tab_path="$TEST_WORKTREES_DIR/with"$'\t'"tab"
  git -C "$TEST_REPO" worktree add "$tab_path" -b tab-path

  local status
  status=$(worktree_status "$tab_path")

  [ "$status" = "ok" ]
}

@test "list_worktree_records preserves registered path containing newline" {
  if ! git -C "$TEST_REPO" worktree list --porcelain -z >/dev/null 2>&1; then
    skip "git worktree list --porcelain -z is not available"
  fi

  local newline_path="${TEST_REPO}-external"$'\n'"newline"
  git -C "$TEST_REPO" worktree add "$newline_path" -b newline-path
  local expected_path
  expected_path=$(cd "$newline_path" && pwd -P)

  local records escaped_path
  escaped_path=$(_tsv_escape_field "$expected_path")
  records=$(list_worktree_records "$TEST_REPO")

  [[ "$records" == *"path $escaped_path"$'\n'"branch newline-path"* ]]

  local status
  status=$(worktree_status "$expected_path")
  [ "$status" = "ok" ]

  resolve_worktree "newline-path" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$expected_path" ]
  [ "$_ctx_branch" = "newline-path" ]
}

# ── discover_repo_root from worktree ──────────────────────────────────────────

@test "discover_repo_root returns main repo root when called from a worktree" {
  create_test_worktree "inside-wt"
  cd "$TEST_WORKTREES_DIR/inside-wt"
  local root expected
  root=$(discover_repo_root)
  # Resolve symlinks (macOS: /var -> /private/var) for comparison
  expected=$(cd "$TEST_REPO" && pwd -P)
  [ "$root" = "$expected" ]
}

@test "discover_repo_root returns main repo root when called from main repo" {
  cd "$TEST_REPO"
  local root expected
  root=$(discover_repo_root)
  expected=$(pwd -P)
  [ "$root" = "$expected" ]
}

@test "discover_repo_root returns main repo root when called from a repo subdirectory" {
  mkdir -p "$TEST_REPO/subdir/nested"
  cd "$TEST_REPO/subdir/nested"
  local root expected
  root=$(discover_repo_root)
  expected=$(cd "$TEST_REPO" && pwd -P)
  [ "$root" = "$expected" ]
}

@test "discover_repo_root returns 1 outside a git repository" {
  local outside_repo
  outside_repo=$(mktemp -d)
  cd "$outside_repo"

  run discover_repo_root
  [ "$status" -eq 1 ]

  rm -rf "$outside_repo"
}

@test "registered path identities select duplicates without changing normal target precedence" {
  create_test_worktree shared
  local selected="$TEST_WORKTREES_DIR/second"
  git worktree add --force "$selected" shared

  resolve_worktree "path:$selected" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$selected" ]
  [ "$_ctx_is_main" = 0 ]
  resolve_worktree shared "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$TEST_WT_PATH" ]
  resolve_worktree second "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$selected" ]
  resolve_worktree 1 "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_is_main" = 1 ]
  resolve_worktree "path:$TEST_REPO" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_is_main" = 1 ]
}

@test "path identities reject stale foreign unregistered and symlink paths" {
  create_test_worktree target
  mkdir "$TEST_REPO/stray" "$TEST_REPO/foreign"
  git -C "$TEST_REPO/foreign" init --quiet
  ln -s "$TEST_WT_PATH" "$TEST_REPO/link"
  local path
  for path in "$TEST_REPO/stray" "$TEST_REPO/foreign" "$TEST_REPO/link" "$TEST_WT_PATH/.."; do
    run resolve_worktree "path:$path" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
    [ "$status" -eq 1 ]
  done
  git worktree remove "$TEST_WT_PATH"
  mkdir "$TEST_WT_PATH"
  run resolve_worktree "path:$TEST_WT_PATH" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$status" -eq 1 ]
}

@test "path identities use the old Git porcelain fallback for ordinary paths" {
  create_test_worktree target
  git() {
    case "$*" in *"worktree list --porcelain -z") return 1 ;; esac
    command git "$@"
  }
  resolve_worktree "path:$TEST_WT_PATH" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$TEST_WT_PATH" ]
}

@test "path identities preserve quotes tabs and shell syntax with old Git fallback" {
  local path="$TEST_WORKTREES_DIR/\"quotes\" café \\ \$(touch should-not-exist)"$'\t'
  git worktree add --detach "$path" HEAD
  git() {
    case "$*" in *"worktree list --porcelain -z") return 1 ;; esac
    command git "$@"
  }
  resolve_worktree "path:$(_tsv_escape_field "$path")" "$TEST_REPO" "$TEST_WORKTREES_DIR" ""
  [ "$_ctx_worktree_path" = "$path" ]
  [ "$_ctx_branch" = '(detached)' ]
  [ ! -e should-not-exist ]
}
