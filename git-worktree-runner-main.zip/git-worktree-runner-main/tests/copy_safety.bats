#!/usr/bin/env bats

setup() {
  load test_helper
  _fast_copy_os=""
  source "$PROJECT_ROOT/lib/platform.sh"
  source "$PROJECT_ROOT/lib/copy.sh"
}

teardown() {
  # Read-only permission fixtures still need to be removable after assertions fail.
  local readonly_path
  for readonly_path in "${_readonly_copy_paths[@]}"; do
    [ -d "$readonly_path" ] && [ ! -L "$readonly_path" ] && chmod u+rwx "$readonly_path"
  done
  if [ -n "${_test_tmpdir:-}" ]; then
    rm -rf "$_test_tmpdir"
  fi
}

_copy_test_mode() {
  stat -c '%a' "$1" 2>/dev/null || stat -f '%Lp' "$1"
}

@test "selective copy keeps new directories private until complete and preserves source modes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" mode
  mkdir -p "$src/vendor/sub/cache" "$dst"
  echo keep > "$src/vendor/sub/keep.txt"
  echo excluded > "$src/vendor/sub/skip.pem"
  echo excluded > "$src/vendor/sub/cache/marker"
  chmod 700 "$src/vendor"
  chmod 750 "$src/vendor/sub"

  cp() {
    [ "$(_copy_test_mode "$dst/$mode/vendor")" = 700 ] || return 1
    [ "$(_copy_test_mode "$dst/$mode/vendor/sub")" = 700 ] || return 1
    command cp "$@"
  }

  # Exercise both triggers for selective traversal.
  for mode in files directories; do
    mkdir "$dst/$mode"
    if [ "$mode" = files ]; then
      (umask 022; copy_directories "$src" "$dst/$mode" vendor '' false '*.pem')
      [ ! -e "$dst/$mode/vendor/sub/skip.pem" ]
    else
      (umask 022; copy_directories "$src" "$dst/$mode" vendor 'vendor/sub/cache')
      [ ! -e "$dst/$mode/vendor/sub/cache" ]
    fi
    [ "$(cat "$dst/$mode/vendor/sub/keep.txt")" = keep ]
    [ "$(_copy_test_mode "$dst/$mode/vendor")" = 700 ]
    [ "$(_copy_test_mode "$dst/$mode/vendor/sub")" = 750 ]
  done
}

@test "selective copy applies the caller umask to new directory modes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/vendor/sub" "$dst"
  echo keep > "$src/vendor/sub/keep.txt"
  chmod 777 "$src/vendor"
  chmod 755 "$src/vendor/sub"

  (umask 077; copy_directories "$src" "$dst" vendor '' false '*.pem')

  [ "$(cat "$dst/vendor/sub/keep.txt")" = keep ]
  [ "$(_copy_test_mode "$dst/vendor")" = 700 ]
  [ "$(_copy_test_mode "$dst/vendor/sub")" = 700 ]
}

@test "selective copy populates read-only source directories before restoring their modes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/vendor/sub" "$dst"
  echo keep > "$src/vendor/sub/keep.txt"
  chmod 500 "$src/vendor"
  chmod 550 "$src/vendor/sub"
  _readonly_copy_paths=("$src/vendor" "$src/vendor/sub" "$dst/vendor" "$dst/vendor/sub")

  (umask 022; copy_directories "$src" "$dst" vendor '' false '*.pem')

  [ "$(cat "$dst/vendor/sub/keep.txt")" = keep ]
  [ "$(_copy_test_mode "$dst/vendor")" = 500 ]
  [ "$(_copy_test_mode "$dst/vendor/sub")" = 550 ]
}

@test "selective copy keeps partial directories private when a leaf copy fails" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/vendor/sub" "$dst"
  echo keep > "$src/vendor/sub/keep.txt"
  chmod 755 "$src/vendor" "$src/vendor/sub"

  cp() {
    command cp "$@" || return 1
    return 1
  }

  cd "$src"
  run _selective_copy_dir vendor "$dst" '' '*.pem'
  [ "$status" -ne 0 ]
  [ "$(_copy_test_mode "$dst/vendor")" = 700 ]
  [ "$(_copy_test_mode "$dst/vendor/sub")" = 700 ]
}

@test "selective copy preserves existing destination directory modes and files" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/vendor/sub" "$dst/vendor/sub"
  echo keep > "$src/vendor/sub/keep.txt"
  echo sentinel > "$dst/vendor/sub/existing"
  chmod 755 "$src/vendor" "$src/vendor/sub"
  chmod 710 "$dst/vendor"
  chmod 700 "$dst/vendor/sub"

  (umask 022; copy_directories "$src" "$dst" vendor '' false '*.pem')

  [ "$(cat "$dst/vendor/sub/keep.txt")" = keep ]
  [ "$(cat "$dst/vendor/sub/existing")" = sentinel ]
  [ "$(_copy_test_mode "$dst/vendor")" = 710 ]
  [ "$(_copy_test_mode "$dst/vendor/sub")" = 700 ]
}

@test "selective copy keeps new directories private when discovery fails" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/vendor" "$dst"
  chmod 755 "$src/vendor"
  find() { return 1; }

  cd "$src"
  run _selective_copy_dir vendor "$dst" '' '*.pem'

  [ "$status" -ne 0 ]
  [ "$(_copy_test_mode "$dst/vendor")" = 700 ]
}

@test "selective copy never finalizes directory permissions through a replacement symlink" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" outside="$_test_tmpdir/outside"
  mkdir -p "$src/vendor" "$dst" "$outside"
  echo sentinel > "$outside/marker"
  chmod 755 "$src/vendor"
  chmod 700 "$outside"
  _apply_directory_excludes() {
    rmdir "$dst/vendor"
    ln -s "$outside" "$dst/vendor"
  }

  cd "$src"
  run _selective_copy_dir vendor "$dst" '' '*.pem'

  [ "$status" -ne 0 ]
  [ "$(_copy_test_mode "$outside")" = 700 ]
  [ "$(cat "$outside/marker")" = sentinel ]
}

@test "nested directory selections preserve restrictive missing source ancestors" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" mode
  mkdir -p "$src/private space/vendor/bundle/cache" "$dst"
  echo keep > "$src/private space/vendor/bundle/keep.txt"
  echo excluded > "$src/private space/vendor/bundle/cache/marker"
  chmod 700 "$src/private space"
  chmod 710 "$src/private space/vendor"
  chmod 755 "$src/private space/vendor/bundle"
  cp() {
    [ "$(_copy_test_mode "$dst/$mode/private space")" = 700 ] || return 1
    [ "$(_copy_test_mode "$dst/$mode/private space/vendor")" = 700 ] || return 1
    command cp "$@"
  }

  for mode in files directories fast; do
    mkdir "$dst/$mode"
    case "$mode" in
      files)
        (umask 022; copy_directories "$src" "$dst/$mode" 'private space/vendor/bundle' '' false '*.pem')
        ;;
      directories)
        (umask 022; copy_directories "$src" "$dst/$mode" 'private space/vendor/bundle' 'private space/vendor/bundle/cache')
        ;;
      fast)
        (umask 022; copy_directories "$src" "$dst/$mode" 'private space/vendor/bundle' '')
        ;;
    esac
    [ "$(cat "$dst/$mode/private space/vendor/bundle/keep.txt")" = keep ]
    [ "$(_copy_test_mode "$dst/$mode/private space")" = 700 ]
    [ "$(_copy_test_mode "$dst/$mode/private space/vendor")" = 710 ]
  done
}

@test "nested directory selections populate siblings before restoring a read-only parent" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/private/a" "$src/private/b" "$dst"
  echo first > "$src/private/a/keep.txt"
  echo second > "$src/private/b/keep.txt"
  chmod 500 "$src/private"
  _readonly_copy_paths=("$src/private" "$dst/private")

  (umask 022; copy_directories "$src" "$dst" $'private/a\nprivate/b' '' false '*.pem')

  [ "$(cat "$dst/private/a/keep.txt")" = first ]
  [ "$(cat "$dst/private/b/keep.txt")" = second ]
  [ "$(_copy_test_mode "$dst/private")" = 500 ]
}

@test "nested directory selections leave missing ancestors private after a copy failure" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/private/vendor" "$dst"
  echo keep > "$src/private/vendor/keep.txt"
  chmod 755 "$src/private" "$src/private/vendor"
  cp() { return 1; }

  local result=0
  (umask 022; copy_directories "$src" "$dst" private/vendor '' false '*.pem') || result=$?

  [ "$result" -ne 0 ]
  [ "$(_copy_test_mode "$dst/private")" = 700 ]
  [ "$(_copy_test_mode "$dst/private/vendor")" = 700 ]
}

@test "nested directory selections propagate permission finalization failures" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/private/vendor" "$dst"
  echo keep > "$src/private/vendor/keep.txt"
  chmod() {
    [ "$2" = "$dst/private" ] && return 1
    command chmod "$@"
  }

  run copy_directories "$src" "$dst" private/vendor '' false '*.pem'

  [ "$status" -ne 0 ]
  [ "$(_copy_test_mode "$dst/private")" = 700 ]
  [ "$(cat "$dst/private/vendor/keep.txt")" = keep ]
}

# --- _is_unsafe_path tests ---

@test "absolute path is unsafe" {
  _is_unsafe_path "/etc/passwd"
}

@test "relative path is safe" {
  ! _is_unsafe_path "src/main.js"
}

@test "parent traversal at start is unsafe" {
  _is_unsafe_path "../secret"
}

@test "parent traversal in middle is unsafe" {
  _is_unsafe_path "foo/../../etc/passwd"
}

@test "parent traversal at end is unsafe" {
  _is_unsafe_path "foo/.."
}

@test "bare double-dot is unsafe" {
  _is_unsafe_path ".."
}

@test "dotfile is safe" {
  ! _is_unsafe_path ".env"
}

@test "nested relative path is safe" {
  ! _is_unsafe_path "src/lib/utils.js"
}

@test "glob pattern is safe" {
  ! _is_unsafe_path "*.txt"
}

@test "double-star glob is safe" {
  ! _is_unsafe_path "**/*.js"
}

# --- is_excluded tests ---

@test "exact match is excluded" {
  is_excluded "node_modules" "node_modules"
}

@test "non-matching path is not excluded" {
  ! is_excluded "src/index.js" "node_modules"
}

@test "glob pattern excludes matching path" {
  is_excluded "build/output.js" "build/*"
}

@test "empty excludes means nothing excluded" {
  ! is_excluded "anything" ""
}

@test "multiple excludes work" {
  local excludes
  excludes=$(printf '%s\n' "*.log" "dist/*" "node_modules")
  is_excluded "error.log" "$excludes"
}

@test "multiple excludes check all patterns" {
  local excludes
  excludes=$(printf '%s\n' "*.log" "dist/*" "node_modules")
  is_excluded "dist/bundle.js" "$excludes"
}

@test "non-matching against multiple excludes" {
  local excludes
  excludes=$(printf '%s\n' "*.log" "dist/*")
  ! is_excluded "src/app.js" "$excludes"
}

@test "leading globstar exclusions match zero or more directory levels" {
  is_excluded "note.txt" "**/note.txt"
  is_excluded "data/note.txt" "**/note.txt"
  is_excluded "data/deep/note.txt" "**/note.txt"
  run is_excluded "other.txt" "**/note.txt"
  [ "$status" -eq 1 ]
  run is_excluded "data/note.txt.bak" "**/note.txt"
  [ "$status" -eq 1 ]
}

@test "leading globstar exclusions preserve suffix globs and spaces" {
  local excludes=$'\n**/.env\n**/secrets.[ab]?\n**/private note.txt\n'
  is_excluded ".env" "$excludes"
  is_excluded "data/.env" "$excludes"
  is_excluded "secrets.a1" "$excludes"
  is_excluded "data/secrets.b2" "$excludes"
  is_excluded "private note.txt" "$excludes"
  is_excluded "data/private note.txt" "$excludes"
  run is_excluded ".env.example" "$excludes"
  [ "$status" -eq 1 ]
  run is_excluded "secrets.c1" "$excludes"
  [ "$status" -eq 1 ]
}

@test "leading globstar exclusions retain explicit suffix directories" {
  is_excluded "data/note.txt" "**/data/note.txt"
  is_excluded "src/data/note.txt" "**/data/note.txt"
  run is_excluded "note.txt" "**/data/note.txt"
  [ "$status" -eq 1 ]
  run is_excluded "other/note.txt" "**/data/note.txt"
  [ "$status" -eq 1 ]
}

@test "repeated leading globstar exclusions can each match zero directories" {
  is_excluded "note.txt" "**/**/note.txt"
  is_excluded "data/note.txt" "**/**/note.txt"
  is_excluded "data/deep/note.txt" "**/**/note.txt"
}

@test "literal exclusions remain relative paths rather than basename matches" {
  is_excluded "note.txt" "note.txt"
  run is_excluded "data/note.txt" "note.txt"
  [ "$status" -eq 1 ]
  is_excluded "data/note.txt" "data/note.txt"
  run is_excluded "src/data/note.txt" "data/note.txt"
  [ "$status" -eq 1 ]
}

@test "ordinary exclusion wildcards retain slash matching behavior" {
  is_excluded "data/deep/note.txt" "*.txt"
  is_excluded "data/deep/note.txt" "data/*"
  is_excluded "data/note.txt" "*/note.txt"
  run is_excluded "note.txt" "*/note.txt"
  [ "$status" -eq 1 ]
  is_excluded "file[1].txt" 'file\[1\].txt'
  run is_excluded "file1.txt" 'file\[1\].txt'
  [ "$status" -eq 1 ]
}

# --- _fast_copy_dir tests ---

@test "_fast_copy_dir copies directory contents" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src" "$dst"
  mkdir -p "$src/mydir/sub"
  echo "hello" > "$src/mydir/sub/file.txt"

  _fast_copy_dir "$src/mydir" "$dst/"

  [ -f "$dst/mydir/sub/file.txt" ]
  [ "$(cat "$dst/mydir/sub/file.txt")" = "hello" ]
}

@test "_fast_copy_dir keeps trailing-slash sources under their basename" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" suffix
  mkdir -p "$src/my dir"
  echo replacement > "$src/my dir/marker"

  for suffix in '' / ///; do
    rm -rf "$dst"
    mkdir -p "$dst"
    echo sentinel > "$dst/marker"
    _fast_copy_dir "$src/my dir$suffix" "$dst/"
    [ "$(cat "$dst/marker")" = sentinel ]
    [ "$(cat "$dst/my dir/marker")" = replacement ]

    # Exercise merging as well as the staging path for a new directory.
    echo keep > "$dst/my dir/destination-only"
    _fast_copy_dir "$src/my dir$suffix" "$dst/"
    [ "$(cat "$dst/marker")" = sentinel ]
    [ "$(cat "$dst/my dir/destination-only")" = keep ]
  done
}

@test "_fast_copy_dir preserves symlinks" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src" "$dst"
  mkdir -p "$src/mydir"
  echo "target" > "$src/mydir/real.txt"
  ln -s real.txt "$src/mydir/link.txt"

  _fast_copy_dir "$src/mydir" "$dst/"

  [ -L "$dst/mydir/link.txt" ]
  [ "$(readlink "$dst/mydir/link.txt")" = "real.txt" ]
}

@test "_fast_copy_dir fails on nonexistent source" {
  _test_tmpdir=$(mktemp -d)
  ! _fast_copy_dir "/nonexistent/path" "$_test_tmpdir/"
}

@test "file copy statuses distinguish success, exclusions, and I/O failures" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/nested" "$dst/conflict"
  echo value > "$src/file"
  echo value > "$src/excluded"
  echo value > "$src/conflict"
  echo value > "$src/nested/file"
  echo blocker > "$dst/nested"
  cd "$src"

  run _copy_pattern_file file "$dst" '' true false
  [ "$status" -eq 0 ]
  [ "$(cat "$dst/file")" = value ]
  run _copy_pattern_file excluded "$dst" excluded true false
  [ "$status" -eq 1 ]
  [ ! -e "$dst/excluded" ]
  run _copy_pattern_file conflict "$dst" '' true false
  [ "$status" -eq 2 ]
  [ -d "$dst/conflict" ]
  run _copy_pattern_file nested/file "$dst" '' true false
  [ "$status" -eq 2 ]
  [ "$(cat "$dst/nested")" = blocker ]
}

@test "both pattern expansion paths retain failures alongside successful and excluded files" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" pattern
  mkdir -p "$src" "$dst/a-fail.txt"
  echo value > "$src/a-fail.txt"
  echo keep > "$src/b-keep.txt"
  echo excluded > "$src/c-skip.txt"
  cd "$src"

  # Plain globs exercise the native loop on every Bash; ** forces the 3.2 fallback.
  for pattern in '*.txt' '**/*.txt'; do
    run _expand_and_copy_pattern "$pattern" "$dst" 'c-skip.txt' true false 0
    [ "$status" -eq 1 ]
    [ "$output" = 1 ]
    [ "$(cat "$dst/b-keep.txt")" = keep ]
    [ ! -e "$dst/c-skip.txt" ]
  done
}

@test "copy_patterns succeeds when every match is intentionally skipped" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src" "$dst"
  echo value > "$src/excluded"
  echo metadata > "$src/.git"

  run copy_patterns "$src" "$dst" $'excluded\n.git\n../outside\nmissing*' excluded

  [ "$status" -eq 0 ]
  [ ! -e "$dst/excluded" ]
  [ ! -e "$dst/.git" ]
}

@test "copy_patterns retains earlier failures and restores cwd and shell options" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/nested" "$dst"
  echo value > "$src/nested/file"
  echo keep > "$src/keep"
  echo excluded > "$src/excluded"
  echo blocker > "$dst/nested"
  local before options_before result=0
  before=$(pwd)
  options_before=$(shopt -p nullglob dotglob globstar 2>/dev/null || true)

  copy_patterns "$src" "$dst" $'nested/file\nkeep\nexcluded\nmissing*' excluded || result=$?

  [ "$result" -eq 1 ]
  [ "$(pwd)" = "$before" ]
  [ "$(shopt -p nullglob dotglob globstar 2>/dev/null || true)" = "$options_before" ]
  [ "$(cat "$dst/keep")" = keep ]
  [ "$(cat "$dst/nested")" = blocker ]
  [ ! -e "$dst/excluded" ]
}

# --- _expand_and_copy_pattern find-fallback tests ---
# These test the Bash 3.2 fallback path (have_globstar=0)

@test "find fallback: empty results don't cause failures" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src" "$dst"

  cd "$src"
  local count
  count=$(_expand_and_copy_pattern "**/.nonexistent*" "$dst" "" "true" "false" "0")
  [ "$count" -eq 0 ]
}

@test "find fallback: **/ pattern matches root-level files" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src" "$dst"
  echo "secret" > "$src/.env"
  echo "local" > "$src/.env.local"

  cd "$src"
  local count
  count=$(_expand_and_copy_pattern "**/.env*" "$dst" "" "true" "false" "0")
  [ "$count" -eq 2 ]
  [ -f "$dst/.env" ]
  [ -f "$dst/.env.local" ]
}

@test "find fallback: **/ pattern matches nested files" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/subdir" "$dst"
  echo "nested" > "$src/subdir/.env"

  cd "$src"
  local count
  count=$(_expand_and_copy_pattern "**/.env" "$dst" "" "true" "false" "0")
  [ "$count" -eq 1 ]
  [ -f "$dst/subdir/.env" ]
}

@test "find fallback: **/ pattern matches both root and nested files" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/config" "$dst"
  echo "root" > "$src/CLAUDE.md"
  echo "nested" > "$src/config/CLAUDE.md"

  cd "$src"
  local count
  count=$(_expand_and_copy_pattern "**/CLAUDE.md" "$dst" "" "true" "false" "0")
  [ "$count" -eq 2 ]
  [ -f "$dst/CLAUDE.md" ]
  [ -f "$dst/config/CLAUDE.md" ]
}

@test "find fallback: globstar exclusions skip root and nested files" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" dir
  mkdir -p "$src/data/deep" "$dst"
  for dir in "$src" "$src/data" "$src/data/deep"; do
    echo "excluded fixture" > "$dir/note.txt"
    echo "included fixture" > "$dir/keep.txt"
  done

  cd "$src"
  local count
  count=$(_expand_and_copy_pattern "**/*.txt" "$dst" "**/note.txt" "true" "false" "0")
  [ "$count" -eq 3 ]
  for dir in "$dst" "$dst/data" "$dst/data/deep"; do
    [ ! -e "$dir/note.txt" ]
    [ "$(cat "$dir/keep.txt")" = "included fixture" ]
  done
}

@test "_apply_directory_excludes supports node_modules/* patterns" {
  _test_tmpdir=$(mktemp -d)
  local dest="$_test_tmpdir/dest"
  mkdir -p "$dest/node_modules/.cache"
  touch "$dest/node_modules/.cache/file"

  _apply_directory_excludes "$dest" "node_modules" $'node_modules/*'

  [ ! -e "$dest/node_modules/.cache" ]
}

@test "_apply_directory_excludes skips patterns targeting .git metadata" {
  _test_tmpdir=$(mktemp -d)
  local dest="$_test_tmpdir/dest"
  mkdir -p "$dest/node_modules/.git"
  touch "$dest/node_modules/.git/config"

  _apply_directory_excludes "$dest" "node_modules" $'node_modules/.git'

  [ -e "$dest/node_modules/.git" ]
}

@test "_has_subdir_excludes returns true for child exclude" {
  _has_subdir_excludes ".claude" $'.claude/worktrees'
}

@test "_has_subdir_excludes returns false for unrelated exclude" {
  ! _has_subdir_excludes ".claude" $'node_modules\n.venv'
}

@test "_has_subdir_excludes returns false for exact parent exclude" {
  ! _has_subdir_excludes ".claude" ".claude"
}

@test "_has_subdir_excludes supports glob prefixes" {
  _has_subdir_excludes ".claude" $'*/worktrees'
}

@test "_has_subdir_excludes supports nested include paths" {
  _has_subdir_excludes "vendor/bundle" $'vendor/bundle/cache'
}

@test "_apply_directory_excludes supports nested include paths" {
  _test_tmpdir=$(mktemp -d)
  local dest="$_test_tmpdir/dest"
  mkdir -p "$dest/vendor/bundle/cache" "$dest/vendor/bundle/gems"
  touch "$dest/vendor/bundle/cache/blob"
  touch "$dest/vendor/bundle/gems/spec"

  _apply_directory_excludes "$dest" "vendor/bundle" $'vendor/bundle/cache'

  [ ! -e "$dest/vendor/bundle/cache" ]
  [ -f "$dest/vendor/bundle/gems/spec" ]
}

@test "_apply_directory_excludes supports nested glob prefixes" {
  _test_tmpdir=$(mktemp -d)
  local dest="$_test_tmpdir/dest"
  mkdir -p "$dest/vendor/bundle/cache" "$dest/vendor/bundle/gems"
  touch "$dest/vendor/bundle/cache/blob"
  touch "$dest/vendor/bundle/gems/spec"

  _apply_directory_excludes "$dest" "vendor/bundle" $'vendor/*/cache'

  [ ! -e "$dest/vendor/bundle/cache" ]
  [ -f "$dest/vendor/bundle/gems/spec" ]
}

@test "_apply_directory_excludes uses deepest matching glob prefix" {
  _test_tmpdir=$(mktemp -d)
  local dest="$_test_tmpdir/dest"
  mkdir -p "$dest/vendor/bundle/cache/tmp" "$dest/vendor/bundle/cache/keep"
  touch "$dest/vendor/bundle/cache/tmp/blob"
  touch "$dest/vendor/bundle/cache/keep/spec"

  _apply_directory_excludes "$dest" "vendor/bundle" $'*/bundle/cache/tmp'

  [ ! -e "$dest/vendor/bundle/cache/tmp" ]
  [ -f "$dest/vendor/bundle/cache/keep/spec" ]
}

@test "_selective_copy_dir skips excluded direct child" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/.claude/settings" "$src/.claude/worktrees" "$dst"
  echo "keep" > "$src/.claude/settings/config.json"
  echo "skip" > "$src/.claude/worktrees/session.json"

  cd "$src"
  _selective_copy_dir ".claude" "$dst" $'.claude/worktrees'

  [ -f "$dst/.claude/settings/config.json" ]
  [ ! -e "$dst/.claude/worktrees" ]
}

@test "_selective_copy_dir skips trailing-slash excluded direct child" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/.claude/settings" "$src/.claude/worktrees" "$dst"
  echo "keep" > "$src/.claude/settings/config.json"
  echo "skip" > "$src/.claude/worktrees/session.json"

  cd "$src"
  _selective_copy_dir ".claude" "$dst" $'.claude/worktrees/'

  [ -f "$dst/.claude/settings/config.json" ]
  [ ! -e "$dst/.claude/worktrees" ]
}

@test "_selective_copy_dir still applies deeper excludes after copy" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/.claude/worktrees/cache" "$src/.claude/worktrees/keep" "$dst"
  echo "skip" > "$src/.claude/worktrees/cache/blob"
  echo "keep" > "$src/.claude/worktrees/keep/session.json"

  cd "$src"
  _selective_copy_dir ".claude" "$dst" $'.claude/worktrees/cache'

  [ ! -e "$dst/.claude/worktrees/cache" ]
  [ -f "$dst/.claude/worktrees/keep/session.json" ]
}

@test "copy_directories does not copy excluded direct child subtree" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" copy_log="$_test_tmpdir/copy.log"
  mkdir -p "$src/.claude/settings" "$src/.claude/worktrees" "$dst"
  echo "keep" > "$src/.claude/settings/config.json"
  echo "skip" > "$src/.claude/worktrees/session.json"

  _fast_copy_dir() {
    printf '%s\n' "$1" >> "$copy_log"
    cp -RP "$1" "$2"
  }

  copy_directories "$src" "$dst" ".claude" $'.claude/worktrees'

  [ -f "$dst/.claude/settings/config.json" ]
  [ ! -e "$dst/.claude/worktrees" ]
  ! grep -qx ".claude/worktrees" "$copy_log"
}

@test "copy_directories does not copy excluded child under nested include path" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" copy_log="$_test_tmpdir/copy.log"
  mkdir -p "$src/vendor/bundle/cache" "$src/vendor/bundle/gems" "$dst"
  echo "skip" > "$src/vendor/bundle/cache/blob"
  echo "keep" > "$src/vendor/bundle/gems/spec"

  _fast_copy_dir() {
    printf '%s\n' "$1" >> "$copy_log"
    cp -RP "$1" "$2"
  }

  copy_directories "$src" "$dst" "vendor/bundle" $'vendor/bundle/cache'

  [ -f "$dst/vendor/bundle/gems/spec" ]
  [ ! -e "$dst/vendor/bundle/cache" ]
  ! grep -qx "vendor/bundle/cache" "$copy_log"
}

@test "directory includes preserve their destination with or without trailing slashes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" dir suffix
  for dir in vendor 'packages/vendor space'; do
    mkdir -p "$src/$dir"
    echo replacement > "$src/$dir/marker"
    for suffix in '' / ///; do
      rm -rf "$dst"
      mkdir -p "$dst/packages"
      echo sentinel > "$dst/marker"
      echo parent-sentinel > "$dst/packages/marker"

      copy_directories "$src" "$dst" "$dir$suffix" ''

      [ "$(cat "$dst/$dir/marker")" = replacement ]
      [ "$(cat "$dst/marker")" = sentinel ]
      [ "$(cat "$dst/packages/marker")" = parent-sentinel ]
    done
  done
}

@test "directory self exclusions match trailing-slash includes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" suffix exclude
  mkdir -p "$src/vendor" "$dst"
  echo excluded > "$src/vendor/marker"
  echo sentinel > "$dst/marker"

  for suffix in '' / ///; do
    for exclude in vendor vendor/ vendor/// 'ven*/'; do
      copy_directories "$src" "$dst" "vendor$suffix" "$exclude"
      [ ! -e "$dst/vendor" ]
      [ "$(cat "$dst/marker")" = sentinel ]
    done
  done
}

@test "directory content exclusions keep the included directory itself" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/vendor/cache" "$dst"
  echo excluded > "$src/vendor/cache/marker"

  copy_directories "$src" "$dst" vendor/ 'vendor/*'

  [ -d "$dst/vendor" ]
  [ ! -e "$dst/vendor/cache" ]
  [ ! -e "$dst/cache" ]
}

@test "directory child exclusions match trailing-slash includes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" suffix exclude
  mkdir -p "$src/vendor/cache" "$src/vendor/keep"
  echo excluded > "$src/vendor/cache/marker"
  echo keep > "$src/vendor/keep/marker"

  for suffix in '' / ///; do
    for exclude in vendor/cache vendor/cache/ '*/cache' '*/cache/'; do
      rm -rf "$dst"
      mkdir -p "$dst"
      copy_directories "$src" "$dst" "vendor$suffix" "$exclude"
      [ "$(cat "$dst/vendor/keep/marker")" = keep ]
      [ ! -e "$dst/vendor/cache" ]
      [ ! -e "$dst/cache" ]
      [ ! -e "$dst/keep" ]
    done
  done
}

@test "directory discovery treats trailing slashes consistently for literals and globs" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" pattern expected suffix
  mkdir -p "$src/vendor" "$src/packages/a/generated" "$src/packages/a/cache"
  for pattern in vendor 'vendor*' 'packages/*/generated' '**/cache' cache; do
    expected=$(_resolve_directory_patterns "$src" "$pattern")
    [ -n "$expected" ]
    for suffix in / ///; do
      [ "$(_resolve_directory_patterns "$src" "$pattern$suffix")" = "$expected" ]
    done
  done
}

@test "trailing-slash includes still reject unsafe paths and source links" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" outside="$_test_tmpdir/outside"
  mkdir -p "$src/.git" "$dst" "$outside"
  echo sentinel > "$outside/marker"
  echo metadata > "$src/.git/config"
  ln -s "$outside" "$src/link"

  copy_directories "$src" "$dst" $'/\n///\n../outside/\n[.][.]/outside/\nlink/\n.git/' ''

  [ -z "$(find "$dst" -mindepth 1 -print)" ]
  [ "$(cat "$outside/marker")" = sentinel ]
}

@test "copy_directories applies file exclusions before copying leaves and preserves existing files" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" copy_log="$_test_tmpdir/copy.log"
  mkdir -p "$src/vendor space/sub" "$src/vendor space/assets.pem" "$dst/vendor space/sub"
  echo excluded > "$src/vendor space/root.pem"
  echo excluded > "$src/vendor space/sub/nested.pem"
  echo excluded > "$src/vendor space/sub/.private"
  echo keep > "$src/vendor space/sub/keep.txt"
  echo keep > "$src/vendor space/assets.pem/keep.txt"
  echo sentinel > "$dst/vendor space/sub/nested.pem"
  echo sentinel > "$dst/vendor space/sub/destination-only.pem"

  cp() {
    printf '%s\n' "$@" >> "$copy_log"
    command cp "$@"
  }

  copy_directories "$src" "$dst" 'vendor space' '' false $'*.pem\nvendor space/sub/.private'

  [ ! -e "$dst/vendor space/root.pem" ]
  [ ! -e "$dst/vendor space/sub/.private" ]
  [ "$(cat "$dst/vendor space/sub/nested.pem")" = sentinel ]
  [ "$(cat "$dst/vendor space/sub/destination-only.pem")" = sentinel ]
  [ "$(cat "$dst/vendor space/sub/keep.txt")" = keep ]
  [ "$(cat "$dst/vendor space/assets.pem/keep.txt")" = keep ]
  ! grep -q 'root.pem\|nested.pem\|/\.private' "$copy_log"
}

@test "copy_directories file exclusions do not follow symlinks or remove their targets" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" outside="$_test_tmpdir/outside"
  mkdir -p "$src/vendor/sub" "$dst" "$outside"
  echo sentinel > "$outside/marker"
  ln -s "$outside" "$src/vendor/sub/link.pem"
  ln -s "$outside" "$src/vendor/sub/keep-link"
  echo keep > "$src/vendor/sub/keep.txt"

  copy_directories "$src" "$dst" vendor '' false '*.pem'

  [ ! -L "$dst/vendor/sub/link.pem" ]
  [ -L "$dst/vendor/sub/keep-link" ]
  [ "$(cat "$outside/marker")" = sentinel ]
  [ "$(cat "$dst/vendor/sub/keep.txt")" = keep ]
}

@test "literal directory patterns do not invoke find" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" find_log="$_test_tmpdir/find.log"
  mkdir -p "$src/build/generated" "$src/node_modules"

  find() {
    printf 'called\n' >> "$find_log"
    return 1
  }

  local resolved
  resolved=$(_resolve_directory_patterns "$src" $'build/generated\nnode_modules\nbuild/missing')

  [ "$resolved" = $'./build/generated\n./node_modules' ]
  [ ! -e "$find_log" ]
}

@test "missing basename retains recursive matching" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src"
  mkdir -p "$src/packages/a/vendor"

  local resolved
  resolved=$(_resolve_directory_patterns "$src" "vendor")

  [ "$resolved" = "./packages/a/vendor" ]
}

@test "copy_directories copies nested basename after root miss" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/packages/a/vendor" "$dst"
  echo "nested" > "$src/packages/a/vendor/marker"

  copy_directories "$src" "$dst" "vendor" ""

  [ -f "$dst/packages/a/vendor/marker" ]
}

@test "missing basename patterns share one recursive scan" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" find_log="$_test_tmpdir/find.log"
  mkdir -p "$src/packages/a/vendor" "$src/packages/b/cache"

  find() {
    printf 'called\n' >> "$find_log"
    command find "$@"
  }

  local resolved
  resolved=$(_resolve_directory_patterns "$src" $'vendor\ncache')

  [ "$(wc -l < "$find_log" | tr -d ' ')" -eq 1 ]
  [ "$(printf '%s\n' "$resolved" | grep -c '^./packages/a/vendor$')" -eq 1 ]
  [ "$(printf '%s\n' "$resolved" | grep -c '^./packages/b/cache$')" -eq 1 ]
}

@test "missing basename glob retains recursive matching" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src"
  mkdir -p "$src/packages/a/vendor-cache"

  local resolved
  resolved=$(_resolve_directory_patterns "$src" "vendor-*")

  [ "$resolved" = "./packages/a/vendor-cache" ]
}

@test "single-star directory patterns are bounded to their explicit depth" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src"
  mkdir -p "$src/one/cache" "$src/one/deep/cache"

  local resolved
  resolved=$(_resolve_directory_patterns "$src" "*/cache")

  [ "$resolved" = "./one/cache" ]
}

@test "double-star directory patterns retain recursive matching" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src"
  mkdir -p "$src/one/cache" "$src/one/deep/cache"

  local resolved
  resolved=$(_resolve_directory_patterns "$src" "**/cache")

  [ "$(printf '%s\n' "$resolved" | grep -c '^./one/cache$')" -eq 1 ]
  [ "$(printf '%s\n' "$resolved" | grep -c '^./one/deep/cache$')" -eq 1 ]
  [ "$(printf '%s\n' "$resolved" | wc -l | tr -d ' ')" -eq 2 ]
}

@test "directory excludes never traverse copied symlinks" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" outside="$_test_tmpdir/outside"
  mkdir -p "$src/deps/nested" "$dst" "$outside/cache"
  echo "sentinel" > "$outside/cache/keep"
  echo "remove" > "$src/deps/nested/remove"
  ln -s "$outside" "$src/deps/nested/link"

  copy_directories "$src" "$dst" deps $'deps/*/link/*/*\ndeps/nested/remove'

  [ "$(cat "$outside/cache/keep")" = sentinel ]
  [ -L "$dst/deps/nested/link" ]
  [ ! -e "$dst/deps/nested/remove" ]
}

@test "directory excludes reject symlinks in the exclusion root" {
  _test_tmpdir=$(mktemp -d)
  local dest="$_test_tmpdir/dest" outside="$_test_tmpdir/outside"
  mkdir -p "$dest" "$outside/deps"
  echo "sentinel" > "$outside/deps/keep"
  ln -s "$outside" "$dest/vendor"
  ln -s "$outside/deps" "$dest/deps"

  _apply_directory_excludes "$dest" vendor/deps 'vendor/deps/*'
  _apply_directory_excludes "$dest" deps 'deps/*'

  [ "$(cat "$outside/deps/keep")" = sentinel ]
}

@test "directory excludes can unlink leaf symlinks including dangling links" {
  _test_tmpdir=$(mktemp -d)
  local dest="$_test_tmpdir/dest" outside="$_test_tmpdir/outside"
  mkdir -p "$dest/deps" "$outside"
  echo "sentinel" > "$outside/keep"
  ln -s "$outside" "$dest/deps/link"
  ln -s "$outside/missing" "$dest/deps/dangling"

  _apply_directory_excludes "$dest" deps $'deps/link/\ndeps/dangling'

  [ ! -L "$dest/deps/link" ]
  [ ! -L "$dest/deps/dangling" ]
  [ "$(cat "$outside/keep")" = sentinel ]
}

@test "directory excludes reject glob spellings of parent traversal and metadata" {
  _test_tmpdir=$(mktemp -d)
  local dest="$_test_tmpdir/dest"
  mkdir -p "$dest/deps/.git" "$dest/sibling"
  echo "metadata" > "$dest/deps/.git/config"
  echo "sentinel" > "$dest/sibling/keep"

  _apply_directory_excludes "$dest" deps $'deps/[.][.]/*\ndeps/[.]git/*\ndeps/./*'

  [ "$(cat "$dest/sibling/keep")" = sentinel ]
  [ "$(cat "$dest/deps/.git/config")" = metadata ]
}

@test "directory excludes preserve spaces and shell options" {
  _test_tmpdir=$(mktemp -d)
  local dest="$_test_tmpdir/dest"
  mkdir -p "$dest/deps/cache space/remove" "$dest/deps/cache space/keep"
  local options_before
  options_before=$(shopt -p nullglob dotglob globstar 2>/dev/null || true)

  _apply_directory_excludes "$dest" deps 'deps/cache space/remove'

  [ ! -e "$dest/deps/cache space/remove" ]
  [ -d "$dest/deps/cache space/keep" ]
  [ "$(shopt -p nullglob dotglob globstar 2>/dev/null || true)" = "$options_before" ]
}

@test "broad includes never overwrite worktree Git pointers or nested metadata" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/nested/.git" "$dst"
  echo source > "$src/.git"
  echo secret > "$src/nested/.git/config"
  echo destination > "$dst/.git"
  copy_patterns "$src" "$dst" '*' ''
  copy_directories "$src" "$dst" nested ''
  [ "$(cat "$dst/.git")" = destination ]
  [ ! -e "$dst/nested/.git" ]
}

@test "expanded traversal cannot copy outside either root" {
  _test_tmpdir=$(mktemp -d)
  mkdir -p "$_test_tmpdir/src" "$_test_tmpdir/dst"
  echo secret > "$_test_tmpdir/victim"
  cd "$_test_tmpdir/src"
  ! _copy_pattern_file '../victim' "$_test_tmpdir/dst" '' true false
  ! _copy_pattern_file '././../victim' "$_test_tmpdir/dst" '' true false
  [ "$(cat "$_test_tmpdir/victim")" = secret ]
}

@test "file copies reject source links and destination leaf and ancestor links" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" outside="$_test_tmpdir/outside"
  mkdir -p "$src/vendor" "$dst" "$outside"
  echo private > "$outside/secret"
  echo replacement > "$src/vendor/secret"
  ln -s "$outside/secret" "$src/leak"
  ln -s "$outside/secret" "$dst/leaf"
  ln -s "$outside" "$dst/vendor"
  echo replacement > "$src/leaf"
  copy_patterns "$src" "$dst" $'leak\nleaf\nvendor/*' ''
  [ ! -e "$dst/leak" ]
  [ "$(cat "$outside/secret")" = private ]
}

@test "directory copies reject destination links at every depth" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" outside="$_test_tmpdir/outside"
  mkdir -p "$src/vendor/cache" "$dst/vendor" "$outside"
  echo private > "$outside/secret"
  echo replacement > "$src/vendor/cache/secret"
  ln -s "$outside" "$dst/vendor/cache"
  run copy_directories "$src" "$dst" vendor ''
  [ "$status" -ne 0 ]
  [ "$(cat "$outside/secret")" = private ]
}

@test "newline discovery never reconstructs a parent traversal record" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/"$'safe\n..' "$dst"
  echo private > "$_test_tmpdir/secret"
  copy_directories "$src" "$dst" '*' ''
  [ ! -e "$dst/secret" ]
  cd "$src"
  local count
  echo value > "$src/"$'safe\n..'"/file"
  count=$(_expand_and_copy_pattern '**/*' "$dst" '' true false 0)
  [ "$count" -eq 0 ]
}

@test "directory merge preserves destination-only files and hard-linked external data" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/cache" "$dst/cache"
  echo private > "$_test_tmpdir/secret"
  ln "$_test_tmpdir/secret" "$dst/cache/value"
  echo replacement > "$src/cache/value"
  echo keep > "$dst/cache/keep"
  copy_directories "$src" "$dst" cache ''
  [ "$(cat "$dst/cache/keep")" = keep ]
  [ "$(cat "$_test_tmpdir/secret")" = private ]
  [ "$(cat "$dst/cache/value")" = replacement ]
}

@test "directory merge keeps new nested directories private and preserves source modes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/source space" dst="$_test_tmpdir/destination space"
  mkdir -p "$src/cache/private/nested" "$dst/cache"
  echo secret > "$src/cache/private/nested/token"
  chmod 700 "$src/cache/private"
  chmod 750 "$src/cache/private/nested"
  chmod 644 "$src/cache/private/nested/token"
  cp() {
    [ "$(_copy_test_mode "$dst/cache/private")" = 700 ] || return 1
    [ "$(_copy_test_mode "$dst/cache/private/nested")" = 700 ] || return 1
    command cp "$@"
  }

  (umask 022; copy_directories "$src" "$dst" cache '')

  [ "$(cat "$dst/cache/private/nested/token")" = secret ]
  [ "$(_copy_test_mode "$dst/cache/private")" = 700 ]
  [ "$(_copy_test_mode "$dst/cache/private/nested")" = 750 ]
  [ "$(_copy_test_mode "$dst/cache/private/nested/token")" = 644 ]
}

@test "directory merge applies restrictive umasks to new directory modes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" mask expected_parent expected_sub
  mkdir -p "$src/cache/new/sub" "$dst"
  echo keep > "$src/cache/new/sub/file"
  chmod 750 "$src/cache/new"
  chmod 711 "$src/cache/new/sub"

  for mask in 027 077; do
    mkdir -p "$dst/$mask/cache"
    (umask "$mask"; copy_directories "$src" "$dst/$mask" cache '')
    if [ "$mask" = 027 ]; then
      expected_parent=750
      expected_sub=710
    else
      expected_parent=700
      expected_sub=700
    fi
    [ "$(cat "$dst/$mask/cache/new/sub/file")" = keep ]
    [ "$(_copy_test_mode "$dst/$mask/cache/new")" = "$expected_parent" ]
    [ "$(_copy_test_mode "$dst/$mask/cache/new/sub")" = "$expected_sub" ]
  done
}

@test "directory merge populates read-only source directories before finalizing modes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/cache/new/sub" "$dst/cache"
  echo keep > "$src/cache/new/sub/file"
  chmod 500 "$src/cache/new"
  chmod 550 "$src/cache/new/sub"
  _readonly_copy_paths=("$src/cache/new" "$src/cache/new/sub"
    "$dst/cache/new" "$dst/cache/new/sub")

  (umask 022; copy_directories "$src" "$dst" cache '')

  [ "$(cat "$dst/cache/new/sub/file")" = keep ]
  [ "$(_copy_test_mode "$dst/cache/new")" = 500 ]
  [ "$(_copy_test_mode "$dst/cache/new/sub")" = 550 ]
}

@test "directory merge preserves existing destination directory modes" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/cache/sub/new" "$dst/cache/sub"
  echo keep > "$src/cache/sub/new/file"
  echo sentinel > "$dst/cache/sub/existing"
  chmod 700 "$src/cache"
  chmod 755 "$src/cache/sub" "$src/cache/sub/new"
  chmod 775 "$dst/cache"
  chmod 710 "$dst/cache/sub"

  (umask 077; copy_directories "$src" "$dst" cache '')

  [ "$(cat "$dst/cache/sub/new/file")" = keep ]
  [ "$(cat "$dst/cache/sub/existing")" = sentinel ]
  [ "$(_copy_test_mode "$dst/cache")" = 775 ]
  [ "$(_copy_test_mode "$dst/cache/sub")" = 710 ]
  [ "$(_copy_test_mode "$dst/cache/sub/new")" = 700 ]
}

@test "directory merge keeps partial directories private when a leaf copy fails" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/cache/new/sub" "$dst/cache"
  echo keep > "$src/cache/new/sub/file"
  chmod 755 "$src/cache/new" "$src/cache/new/sub"
  cp() {
    command cp "$@" || return 1
    return 1
  }

  local result=0
  (umask 022; _fast_copy_dir "$src/cache" "$dst") || result=$?

  [ "$result" -ne 0 ]
  [ "$(_copy_test_mode "$dst/cache/new")" = 700 ]
  [ "$(_copy_test_mode "$dst/cache/new/sub")" = 700 ]
}

@test "directory merge leaves directories private when final chmod fails" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/cache/new/sub" "$dst/cache"
  echo keep > "$src/cache/new/sub/file"
  chmod 755 "$src/cache/new" "$src/cache/new/sub"
  chmod() {
    [ "$2" != "$dst/cache/new/sub" ] || return 1
    command chmod "$@"
  }

  run _fast_copy_dir "$src/cache" "$dst"

  [ "$status" -ne 0 ]
  [ "$(cat "$dst/cache/new/sub/file")" = keep ]
  [ "$(_copy_test_mode "$dst/cache/new")" = 700 ]
  [ "$(_copy_test_mode "$dst/cache/new/sub")" = 700 ]
}

@test "directory merge never finalizes permissions through a replacement symlink" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" outside="$_test_tmpdir/outside"
  mkdir -p "$src/cache/new" "$dst/cache" "$outside"
  echo keep > "$src/cache/new/file"
  echo sentinel > "$outside/marker"
  chmod 755 "$src/cache/new"
  chmod 700 "$outside"
  rmdir() {
    command rmdir "$@" || return 1
    case "$1" in
      "$dst/cache/new"/.gtr-copy.*)
        command mv "$dst/cache/new" "$dst/cache/saved"
        ln -s "$outside" "$dst/cache/new"
        ;;
    esac
  }

  run _fast_copy_dir "$src/cache" "$dst"

  [ "$status" -ne 0 ]
  [ -L "$dst/cache/new" ]
  [ "$(_copy_test_mode "$outside")" = 700 ]
  [ "$(cat "$outside/marker")" = sentinel ]
}

@test "failed clone fallback only removes its own staging output" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/cache" "$dst"
  echo value > "$src/cache/file"
  _fast_copy_os=darwin
  cp() {
    if [ "$1" = -cRP ]; then
      mkdir -p "$4/cache"
      echo partial > "$4/cache/partial"
      return 1
    fi
    command cp "$@"
  }
  _fast_copy_dir "$src/cache" "$dst/"
  [ "$(cat "$dst/cache/file")" = value ]
  [ ! -e "$dst/cache/partial" ]
  [ "$(find "$dst" -name '.gtr-copy.*' | wc -l | tr -d ' ')" -eq 0 ]
}

@test "staged directory merges preserve executable file permissions" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/tools" "$dst/tools"
  printf '#!/bin/sh\necho executable\n' > "$src/tools/run"
  chmod +x "$src/tools/run"
  echo unrelated > "$dst/tools/existing"
  _fast_copy_dir "$src/tools" "$dst/"
  [ -x "$dst/tools/run" ]
  [ "$("$dst/tools/run")" = executable ]
}

@test "staged file copies respect a restrictive umask" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src" "$dst"
  echo secret > "$src/.env"
  chmod 644 "$src/.env"
  (umask 077; copy_patterns "$src" "$dst" .env '')
  local mode
  mode=$(stat -c '%a' "$dst/.env" 2>/dev/null) || mode=$(stat -f '%Lp' "$dst/.env")
  [ "$mode" = 600 ]
}

@test "staged replacements retain restrictive existing destination permissions" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src" "$dst"
  echo secret > "$src/.env"
  chmod 644 "$src/.env"
  echo old > "$dst/.env"
  chmod 600 "$dst/.env"
  (umask 022; copy_patterns "$src" "$dst" .env '')
  local mode
  mode=$(stat -c '%a' "$dst/.env" 2>/dev/null) || mode=$(stat -f '%Lp' "$dst/.env")
  [ "$mode" = 600 ]
  [ "$(cat "$dst/.env")" = secret ]
}

@test "preserved directory symlinks never chmod their external referents" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" outside="$_test_tmpdir/secret"
  mkdir -p "$src/cache" "$dst/cache"
  echo private > "$outside"
  chmod 600 "$outside"
  ln -s "$outside" "$src/cache/link"
  echo old > "$dst/cache/link"
  chmod 644 "$dst/cache/link"
  copy_directories "$src" "$dst" cache ''
  [ -L "$dst/cache/link" ]
  local mode
  mode=$(stat -c '%a' "$outside" 2>/dev/null) || mode=$(stat -f '%Lp' "$outside")
  [ "$mode" = 600 ]
  [ "$(cat "$outside")" = private ]
}

@test "copy guards reject case variants of Git metadata on every platform" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/nested/.GiT" "$dst"
  echo source > "$src/.GIT"
  echo metadata > "$src/nested/.GiT/config"
  echo destination > "$dst/.git"
  copy_patterns "$src" "$dst" '.GIT' ''
  copy_directories "$src" "$dst" nested ''
  [ "$(cat "$dst/.git")" = destination ]
  [ ! -e "$dst/.GIT" ] || [ "$(cat "$dst/.GIT")" = destination ]
  [ ! -e "$dst/nested/.GiT" ]
  mkdir -p "$dst/nested/.GiT"
  echo keep > "$dst/nested/.GiT/config"
  _apply_directory_excludes "$dst" nested 'nested/.GiT'
  [ "$(cat "$dst/nested/.GiT/config")" = keep ]
}

@test "directory staging is rejected if Git metadata removal fails" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst" mock_bin="$_test_tmpdir/bin"
  mkdir -p "$src/cache/.git" "$dst" "$mock_bin"
  echo metadata > "$src/cache/.git/config"
  cat > "$mock_bin/rm" <<'SH'
#!/usr/bin/env bash
for arg in "$@"; do
  case "$arg" in */.git) exit 1 ;; esac
done
exec /bin/rm "$@"
SH
  chmod +x "$mock_bin/rm"
  PATH="$mock_bin:$PATH" run _fast_copy_dir "$src/cache" "$dst/"
  [ "$status" -ne 0 ]
  [ ! -e "$dst/cache" ]
  [ "$(find "$dst" -name '.gtr-copy.*' | wc -l | tr -d ' ')" -eq 0 ]
}

@test "directory staging is rejected when metadata verification cannot scan it" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/cache" "$dst"
  echo value > "$src/cache/file"
  find() {
    case "$*" in *'-print -quit'*) return 1 ;; esac
    command find "$@"
  }
  run _fast_copy_dir "$src/cache" "$dst/"
  [ "$status" -ne 0 ]
  [ ! -e "$dst/cache" ]
}

@test "directory publication does not follow a symlink inserted at the move boundary" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/source space" dst="$_test_tmpdir/destination space"
  local outside="$_test_tmpdir/outside"
  mkdir -p "$src/cache" "$dst" "$outside"
  echo value > "$src/cache/file"
  echo sentinel > "$outside/keep"
  # Deterministically schedule the other writer after all pre-copy checks.
  # The actual system mv still performs the move with the production options.
  mv() {
    ln -s "$outside" "$dst/cache"
    command mv "$@"
  }

  run _fast_copy_dir "$src/cache" "$dst/"

  [ "$status" -ne 0 ]
  [ -L "$dst/cache" ]
  [ ! -e "$outside/cache" ]
  [ "$(cat "$outside/keep")" = sentinel ]
  [ "$(find "$dst" -name '.gtr-copy.*' | wc -l | tr -d ' ')" -eq 0 ]
}

@test "directory copy failures reach the caller and restore its working directory" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  mkdir -p "$src/cache" "$dst"
  echo value > "$src/cache/file"
  mv() { return 1; }
  local before result=0
  before=$(pwd)

  copy_directories "$src" "$dst" cache '' || result=$?

  [ "$result" -ne 0 ]
  [ "$(pwd)" = "$before" ]
  [ ! -e "$dst/cache" ]
  [ "$(find "$dst" -name '.gtr-copy.*' | wc -l | tr -d ' ')" -eq 0 ]
}

@test "staged leaf publication replaces a raced symlink without writing its referent" {
  _test_tmpdir=$(mktemp -d)
  local src="$_test_tmpdir/src" dst="$_test_tmpdir/dst"
  local outside="$_test_tmpdir/outside"
  mkdir -p "$src" "$dst" "$outside"
  echo value > "$src/file"
  echo sentinel > "$outside/leaf"
  mv() {
    ln -s "$outside" "$dst/file"
    command mv "$@"
  }

  _copy_tree_entry "$src/file" "$dst/file"

  [ ! -L "$dst/file" ]
  [ "$(cat "$dst/file")" = value ]
  [ "$(cat "$outside/leaf")" = sentinel ]
  [ "$(find "$dst" -name '.gtr-copy.*' | wc -l | tr -d ' ')" -eq 0 ]
}
